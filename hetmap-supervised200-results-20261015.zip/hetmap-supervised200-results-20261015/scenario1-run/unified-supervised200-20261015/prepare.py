"""Export frozen node features and audited directed merged graphs; no training."""
from pathlib import Path
import sys,json,hashlib,collections
import numpy as np
import pandas as pd
import torch
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'code'))
from hetmap.experiments.config import GraphConfig
from hetmap.build_graph.hetero_data import HeterogeneousData
from torch_geometric.data import HeteroData

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,d):
 p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(d,indent=2)+'\n')
def norm(x):
 x=np.asarray(x,dtype=np.float32);n=np.linalg.norm(x,axis=1,keepdims=True)
 return (x/np.where(n>0,n,1)).astype(np.float32)
def edges(pairs):return np.array(sorted(pairs),dtype=np.int64).reshape(-1,2).T.copy()

def prepare():
 torch.set_num_threads(4)
 manifest=json.loads((ROOT/'raw-manifest.json').read_text())
 for path,h in manifest.items():assert sha(ROOT/path)==h,path
 records=[]
 for system in json.loads((ROOT/'protocol.json').read_text())['systems']:
  p=ROOT/'raw'/system;ref=json.loads((p/'splits.json').read_text());files=ref['files'];classes=sorted(set(ref['labels']))
  df=pd.read_csv(p/'dataset.csv');deps=pd.read_csv(p/'dataset_deps.csv');fidx={f:i for i,f in enumerate(files)}
  reference_deps=pd.read_csv(p/'file-dependencies-reference.csv')
  expected={(fidx[r.Source_File],fidx[r.Target_File]) for r in reference_deps.itertuples() if r.Source_File!=r.Target_File}
  for config in ['F','FM','FF','FFM']:
   members=config in ['FM','FFM'];folders=config in ['FF','FFM']
   gc=GraphConfig(keep_member_nodes=members,folder_edges=folders,use_w2v_features=False,loc_features=False)
   base=HeterogeneousData(df,deps,gc)
   assert list(base.file_id)==files,system
   assert base.df.Module.astype(str).tolist()==ref['labels'],system
   assert base.use_member_graph==members,(system,config)
   ownership={'file':np.arange(len(files))}
   if members:ownership['member']=np.array([fidx[base.member_file_map[mid]] for mid in base.member_id])
   # Independent endpoint extraction retains original routing to aggregate member nodes.
   merged=collections.defaultdict(set);removed=0;rawcount=0
   for r in base.df_dep_raw.itertuples(index=False):
    if r.Source_File==r.Target_File:removed+=1;continue
    st,u=base._endpoint(r,'Source');tt,v=base._endpoint(r,'Target')
    assert u is not None and v is not None
    merged[(st,'dependency',tt)].add((u,v));rawcount+=1
   if not members:merged.setdefault(('file','dependency','file'),set());assert merged[('file','dependency','file')]==expected
   for rel in list(base.edge_types):
    if rel[1] not in ['parent_of','contains','belongs_to']:del base[rel]
   for rel in sorted(merged):
    arr=edges(merged[rel]);base[rel].edge_index=torch.from_numpy(arr)
    assert (ownership[rel[0]][arr[0]]!=ownership[rel[2]][arr[1]]).all()
   owner_union={(int(ownership[rel[0]][u]),int(ownership[rel[2]][v])) for rel,pairs in merged.items() for u,v in pairs}
   assert owner_union==expected,(system,config,'member graph lost file dependencies')
   for rep in (['W2V','N2V','UXC_ZS','UXC_FT'] if config=='F' else ['W2V','N2V','UXC_FT']):
    f=p/rep;keys=json.loads((f/'file-keys.json').read_text());assert keys==files
    x=np.load(f/'x.npy') # Exactly the frozen normalized file cache used by the 100-split controls.
    if rep=='W2V' and members:
     assert json.loads((f/'rq2-file-keys.json').read_text())==files
     x=norm(np.load(f/'rq2-filename.npy'))
    g=HeteroData()
    for nt in base.node_types:
     if nt=='file':a=x.copy()
     elif nt=='folder':a=base[nt].x.numpy().copy() # Existing binary folder-token features, unchanged.
     elif rep=='N2V':a=x[ownership['member']].copy()
     elif rep=='W2V':a=norm(np.load(f/'rq2-member.npy'))[ownership['member']]
     else:
      raw=np.load(f/'member-source.npy');kk=(f/'member-source-keys.txt').read_text().splitlines();index={k:i for i,k in enumerate(kk)}
      a=np.zeros((len(ownership['member']),raw.shape[1]),dtype=np.float32);matched=0
      for i,owner in enumerate(ownership['member']):
       key=files[owner];j=index.get(key)
       if j is None and '/' in key:j=index.get(key.split('/',1)[1])
       if j is not None:a[i]=raw[j];matched+=1
      assert matched==len(a),(system,'member cache keys missing',matched,len(a))
      a=norm(a)
     assert np.isfinite(a).all() and a.ndim==2 and a.shape[1]>0
     g[nt].x=torch.from_numpy(a)
    for rel in base.edge_types:g[rel].edge_index=base[rel].edge_index.clone()
    out=ROOT/'inputs'/system/rep/config;out.mkdir(parents=True,exist_ok=True)
    arrays={f'x_{nt}':g[nt].x.numpy() for nt in g.node_types}
    arrays.update({f'edge_{i}':g[rel].edge_index.numpy() for i,rel in enumerate(g.edge_types)})
    for nt,a in ownership.items():arrays[f'owner_{nt}']=a
    np.savez_compressed(out/'graph.npz',**arrays)
    info=dict(system=system,representation=rep,config=config,node_types=g.node_types,edge_types=g.edge_types,
      node_shapes={nt:list(g[nt].x.shape) for nt in g.node_types},edge_counts={str(e):g[e].num_edges for e in g.edge_types},
      zero_feature_rows={nt:int((np.linalg.norm(g[nt].x.numpy(),axis=1)==0).sum()) for nt in g.node_types},
      removed_within_file_dependency_rows=removed,retained_raw_dependency_rows=rawcount,
      merged_dependency_edges=sum(len(v) for v in merged.values()),file_dependency_pairs=len(expected),
      feature_policy='Frozen caches; row L2 for file/member embeddings; existing binary folder features unchanged',
      raw_splits_sha256=sha(p/'splits.json'),file_features_raw_bytes_sha256=hashlib.sha256(g['file'].x.numpy().tobytes()).hexdigest(),
      files=files,classes=classes,labels=[classes.index(label) for label in ref['labels']])
    save(out/'metadata.json',info);records.append({k:v for k,v in info.items() if k not in ['files','labels']})
  print(json.dumps(dict(event='system_prepared',system=system)),flush=True)
 paths={str(p.relative_to(ROOT)):sha(p) for p in sorted((ROOT/'inputs').rglob('*')) if p.is_file()}
 save(ROOT/'prepared-manifest.json',paths);save(ROOT/'preparation.json',dict(complete=True,conditions=len(records),records=records))

if __name__=='__main__':prepare()
