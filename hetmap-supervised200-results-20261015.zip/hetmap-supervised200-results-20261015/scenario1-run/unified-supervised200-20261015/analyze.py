"""Verify all requested fits and export overlapping RQ selections explicitly."""
import concurrent.futures,time
import pandas as pd
from sklearn.metrics import f1_score
from common import *

def verify_task(index):
 task=json.loads((ROOT/'tasks.json').read_text())[index];ref=json.loads((ROOT/'raw'/task['system']/'splits.json').read_text());rows=[]
 status=json.loads((ROOT/'outputs/tasks'/f'{index:04}.json').read_text());assert status['state']=='complete'
 for run in range(task['start'],task['stop']):
  test=ref['splits'][str(run)]['test_indices'];expected_files=[ref['files'][i] for i in test];truth=[ref['labels'][i] for i in test];group=[]
  for condition in task['conditions']:
   out=group_path(task,run)/condition;receipt=json.loads((out/'receipt.json').read_text());assert receipt['complete'] and receipt['protocol_sha256']==sha(ROOT/'protocol.json')
   for f,h in receipt['sha256'].items():assert sha(out/f)==h,(out,f)
   validation=json.loads((out/'validation.json').read_text());assert validation['complete'] and validation['checkpoint_replay_checked']
   row=json.loads((out/'metrics.json').read_text());assert row['epochs']==200 and row['schedule']=='supervised200' and row['init_seed']==42+run
   assert all(row[k]==task[k] for k in ['system','representation','config','model']) and row['condition']==condition and row['run_id']==run
   prediction=pd.read_csv(out/'predictions.csv.gz');assert prediction.file_path.tolist()==expected_files and prediction.true_module.tolist()==truth
   for avg in ['macro','micro']:
    kw=dict(labels=sorted(set(truth)),zero_division=0) if avg=='macro' else {}
    assert abs(row[f'f1_{avg}']-100*f1_score(truth,prediction.pred_module,average=avg,**kw))<1e-8
   group.append(row);rows.append(row)
  assert len({r['initial_weights_hash'] for r in group})==1
  assert len({r['parameter_count'] for r in group})==1
 return rows

if __name__=='__main__':
 start=time.perf_counter();p=verify();tasks=json.loads((ROOT/'tasks.json').read_text());rows=[]
 with concurrent.futures.ProcessPoolExecutor(max_workers=8) as pool:
  for batch in pool.map(verify_task,range(len(tasks))):rows.extend(batch)
 d=pd.DataFrame(rows);keys=['system','representation','config','model','condition','run_id']
 assert len(d)==45000 and not d.duplicated(keys).any();assert d.groupby(keys[:-1]).size().eq(100).all()
 out=ROOT/'outputs/analysis';out.mkdir(parents=True,exist_ok=True);d.to_csv(out/'long-format.csv',index=False)
 rq1=d[(d.model=='NeighborMLP')&(d.condition=='off')];rq2=d[(d.model=='HGT')&(d.condition=='directed')&d.representation.isin(p['rq2_representations'])];rq3=d[d.config=='F']
 assert (len(rq1),len(rq2),len(rq3))==(4000,12000,36000)
 for name,frame in [('rq1',rq1),('rq2',rq2),('rq3',rq3)]:
  frame.to_csv(out/f'{name}-per-run.csv',index=False)
  frame.groupby(keys[:-1])[['f1_macro','f1_micro']].median().reset_index().to_csv(out/f'{name}-medians.csv',index=False)
 contrast_rows=[]
 for (system,rep,model),g in rq3.groupby(['system','representation','model']):
  a=g.pivot(index='run_id',columns='condition',values=['f1_macro','f1_micro'])
  for left,right in [('directed','off'),('undirected','off'),('undirected','directed')]:
   for metric in ['f1_macro','f1_micro']:
    delta=a[metric][left]-a[metric][right]
    for run,value in delta.items():contrast_rows.append(dict(system=system,representation=rep,model=model,contrast=f'{left}-minus-{right}',metric=metric,run_id=int(run),delta_pp=float(value)))
 contrasts=pd.DataFrame(contrast_rows);contrasts.to_csv(out/'rq3-paired-deltas.csv',index=False)
 contrasts.groupby(['system','representation','model','contrast','metric']).delta_pp.agg(['median','mean','min','max']).reset_index().to_csv(out/'rq3-effects.csv',index=False)
 save(out/'validation.json',dict(complete=True,fits=len(d),metrics_checked=2*len(d),checkpoint_replay_checked=True,initialization_pairing_checked=True,
   rq1_rows=len(rq1),rq2_rows=len(rq2),rq3_rows=len(rq3),rq1_off_reused=True,rq2_F_reused=True,protocol_sha256=sha(ROOT/'protocol.json'),seconds=time.perf_counter()-start))
 save(ROOT/'outputs/status.json',dict(state='complete',fits=len(d),validation='outputs/analysis/validation.json'))
 print(json.dumps(dict(event='all_results_verified',fits=len(d))),flush=True)
