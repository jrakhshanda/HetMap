"""Standard GATConv in the same outer projection/residual/norm/head design."""
import torch
from torch_geometric.nn import GATConv
from shared import EDGE
class GATNet(torch.nn.Module):
 def __init__(self,in_channels,out_channels):
  super().__init__()
  self.projection=torch.nn.Linear(in_channels,256)
  # Explicit within-file edges come from the frozen matched graph. No new loops.
  self.conv=GATConv(256,64,heads=4,concat=True,negative_slope=.2,dropout=0.,add_self_loops=False,bias=True)
  self.norm=torch.nn.LayerNorm(256)
  self.classifier=torch.nn.Linear(256,out_channels)
  assert getattr(self.conv,'res',None) is None,'Do not add an internal residual branch'
 def forward(self,data):
  own=self.projection(data['file'].x).relu()
  hidden=self.norm(self.conv(own,data[EDGE].edge_index)+own)
  return self.classifier(hidden),{'file':hidden}
def make_model(kind,data,k):
 assert kind=='gat'
 m=GATNet(data['file'].x.shape[1],k).cuda()
 m.apply(lambda v:v.reset_parameters() if hasattr(v,'reset_parameters') else None)
 return m
