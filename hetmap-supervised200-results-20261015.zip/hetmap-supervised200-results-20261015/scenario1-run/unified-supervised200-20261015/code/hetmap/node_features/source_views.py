"""Scenario-1 source views: type/state/constructors vs ordinary operations.

Java deliberately uses the original extractor. C/C++ preserve physical-file
boundaries and do not expand includes or macros. This is syntax extraction,
not a compiler frontend. Parse errors are reported, never hidden as success.
"""
from __future__ import annotations

from dataclasses import dataclass, asdict, field
from functools import lru_cache
from pathlib import Path
import importlib
import re

EXTRACTION_VERSION = "scenario1-v4.3"
PROJECT_LANGUAGES = {"bash": "c", "hdf": "c", "hdc": "cpp", "chromium": "cpp"}


@dataclass
class SourceViews:
    file_text: str
    member_text: str
    language: str
    has_error: bool
    error_nodes: int
    missing_nodes: int
    file_content_empty: bool
    member_content_empty: bool
    member_fragments: int
    prototype_wrappers_normalized: int = 0
    raw_has_error: bool = False
    old_style_definitions_normalized: int = 0
    conditional_profiles: int = 1
    conditional_branches_uncovered: int = 0
    malformed_conditionals: int = 0
    body_error_nodes: int = 0
    outside_body_error_nodes: int = 0
    declaration_macros: list = field(default_factory=list)
    parse_diagnostics: list = field(default_factory=list)
    member_source_spans: list = field(default_factory=list)
    function_bodies_extended: int = 0
    signature_macros_normalized: int = 0

    def to_dict(self):
        return asdict(self)


def language_for(path: str, project: str, overrides: dict | None = None) -> str:
    if overrides and path in overrides:
        language = overrides[path]
    elif Path(path).suffix == ".java":
        language = "java"
    elif Path(path).suffix == ".c":
        language = "c"
    elif Path(path).suffix in {".cc", ".cpp", ".cxx", ".C", ".hh", ".hpp", ".hxx"}:
        language = "cpp"
    elif Path(path).suffix == ".h":
        language = PROJECT_LANGUAGES.get(project)
    else:
        language = None
    if language not in {"java", "c", "cpp"}:
        raise ValueError(f"Explicit language override required for {project}:{path}")
    return language


@lru_cache(maxsize=3)
def get_parser(language: str):
    from tree_sitter import Language, Parser
    grammar = importlib.import_module("tree_sitter_" + language)
    return Parser(Language(grammar.language()))


def _walk(node):
    yield node
    for child in node.children:
        yield from _walk(child)


def _text(node):
    return node.text.decode("utf-8", errors="replace") if node else ""


def _declarator(node):
    """Return (name, nearest binding operator): handles pointer-to-function vars."""
    chain = []
    while node is not None:
        # Conversion functions have an operator_cast rather than a named
        # function_declarator (even when converting to a pointer type).
        if node.type == "operator_cast":
            return _text(node), "function_declarator"
        chain.append(node)
        child = node.child_by_field_name("declarator")
        if child is None and node.type in {"parenthesized_declarator", "attributed_declarator", "reference_declarator"}:
            child = next((c for c in node.named_children if "attribute" not in c.type), None)
        if child is None:
            break
        node = child
    operators = {"function_declarator", "pointer_declarator", "reference_declarator", "array_declarator"}
    nearest = next((n.type for n in reversed(chain[:-1]) if n.type in operators), None)
    return (_text(chain[-1]) if chain else "", nearest)


def _constructor(node, class_name):
    name, operator = _declarator(node.child_by_field_name("declarator"))
    if operator != "function_declarator" or node.child_by_field_name("type") is not None:
        return False
    parts = name.split("::")
    base = lambda s: re.sub(r"<.*>", "", s).strip()
    return ((class_name is not None and base(parts[-1]) == base(class_name)) or
            (len(parts) >= 2 and base(parts[-1]) == base(parts[-2])))


def extract_source_views(source: str, language: str, prefix: str = "", *, legacy_java=False) -> SourceViews:
    parse_language = "java" if legacy_java else language
    raw = source.encode("utf-8", errors="replace")
    if parse_language == "java":
        tree = get_parser("java").parse(raw)
        root = tree.root_node
        from hetmap.node_features.unixcoder_emb import extract_file_view, extract_methods_text
        file_text = extract_file_view(source, prefix)
        member_text = extract_methods_text(source)
        nodes = list(_walk(root))
        return SourceViews(file_text, member_text, parse_language, root.has_error,
                           sum(n.type == "ERROR" for n in nodes), sum(n.is_missing for n in nodes),
                           file_text == (prefix + " [empty]").strip(), not bool(member_text),
                           sum(n.type == "method_declaration" for n in nodes), raw_has_error=root.has_error)
    from .c_family_views import extract
    result = extract(raw, language, get_parser(language), _declarator, _constructor)
    content = result.pop("content")
    file_text = (("PATH: " + prefix + "\n") if prefix else "") + content if content else (prefix + " [empty]").strip()
    return SourceViews(file_text=file_text, language=language, file_content_empty=not bool(content),
                       member_content_empty=not bool(result["member_text"]), **result)
