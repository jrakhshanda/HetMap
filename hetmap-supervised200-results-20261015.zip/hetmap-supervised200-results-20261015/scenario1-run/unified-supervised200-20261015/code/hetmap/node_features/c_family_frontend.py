"""Offset-preserving syntax preparation, without includes or macro expansion.

Conditional profiles cover physical branches rather than selecting a build.
Repeated conditions share choices. Profiles are bounded and uncovered branches
are reported explicitly. All emitted content comes from the original source.
"""
from dataclasses import dataclass, field
from bisect import bisect_right
import re


TOKEN = re.compile(
    rb'(?P<comment>//(?:\\\r?\n|[^\n])*|/\*[\s\S]*?\*/)'
    rb'|(?P<raw>(?:u8|u|U|L)?R"(?P<delimiter>[^ ()\\\t\r\n]{0,16})\([\s\S]*?\)(?P=delimiter)")'
    rb'|(?P<string>(?:u8|u|U|L)?"(?:\\[\s\S]|[^"\\])*"|(?:u|U|L)?\'(?:\\[\s\S]|[^\'\\])*\')'
    rb'|(?P<identifier>[a-zA-Z_\x80-\xff][a-zA-Z_0-9\x80-\xff]*)'
    rb'|(?P<punct>[^\s])')


def blank(raw):
    return re.sub(rb'[^\r\n]', b' ', raw)


def mask(buf, start, end):
    buf[start:end] = blank(buf[start:end])


def lexical(raw):
    return list(TOKEN.finditer(raw))


def code_mask(raw, strings=False):
    result = bytearray(raw)
    for token in TOKEN.finditer(raw):
        if token.lastgroup == 'comment' or (strings and token.lastgroup in {'string', 'raw'}):
            mask(result, token.start(), token.end())
    return result


def directives(raw):
    """Logical directive spans; do not recognize text in comments or literals."""
    safe = code_mask(raw, strings=True)
    result, consumed = [], 0
    for match in re.finditer(rb'(?m)^[ \t]*#[ \t]*(\w+)\b', safe):
        if match.start() < consumed:
            continue
        end = raw.find(b'\n', match.end())
        end = len(raw) if end < 0 else end + 1
        # Splice exactly one physical line ending. Stripping all newlines
        # incorrectly consumes a blank line and then the following directive.
        while end < len(raw) and raw[max(match.start(), end - 3):end].endswith((b'\\\n', b'\\\r\n')):
            next_end = raw.find(b'\n', end)
            end = len(raw) if next_end < 0 else next_end + 1
        consumed = end
        value = re.sub(rb'\\\r?\n', b' ', bytes(code_mask(raw[match.end():end]))).strip()
        result.append((match.start(), end, match.group(1).decode(), value))
    return result


def condition(kind, value):
    """Canonical symbolic condition plus polarity (not a C constant evaluator)."""
    s = re.sub(rb'\s+', b'', value).decode('utf-8', errors='replace')
    if kind in {'ifdef', 'ifndef'}:
        return 'defined(' + s + ')', kind == 'ifdef'
    s = re.sub(r'defined\(?([A-Za-z_]\w*)\)?', r'defined(\1)', s)
    def unwrap(text):
        while text.startswith('(') and text.endswith(')'):
            depth = 0
            for i, c in enumerate(text):
                depth += (c == '(') - (c == ')')
                if depth == 0:
                    break
            if i != len(text) - 1:
                break
            text = text[1:-1]
        return text
    s = unwrap(s)
    positive = True
    while s.startswith('!') and not s.startswith('!='):
        # Only invert a whole expression, not the first term of !A && B.
        rest = s[1:]
        if '&&' in unwrap(rest) or '||' in unwrap(rest):
            if not (rest.startswith('(') and rest.endswith(')')):
                break
        s, positive = unwrap(rest), not positive
    return s, positive


@dataclass
class Group:
    start: int
    end: int
    parents: tuple
    arms: list = field(default_factory=list)  # [start, end, symbolic condition or None]


class Source:
    def __init__(self, raw):
        self.raw = raw
        self.clean = bytes(code_mask(raw))
        self.comments = [(t.start(), t.end()) for t in TOKEN.finditer(raw) if t.lastgroup == 'comment']
        self.comment_ends = [b for _, b in self.comments]
        self.directives = directives(raw)
        self.groups = []
        stack = []
        self.malformed_conditionals = 0
        for start, end, kind, value in self.directives:
            if kind in {'if', 'ifdef', 'ifndef'}:
                group = Group(start, len(raw), tuple(stack))
                group.arms.append([end, len(raw), condition(kind, value)])
                self.groups.append(group)
                stack.append((len(self.groups) - 1, 0))
            elif kind in {'elif', 'else', 'elifdef', 'elifndef'}:
                if not stack:
                    self.malformed_conditionals += 1
                    continue
                index, arm = stack[-1]
                group = self.groups[index]
                group.arms[arm][1] = start
                cond = None if kind == 'else' else condition(
                    {'elifdef': 'ifdef', 'elifndef': 'ifndef'}.get(kind, 'if'), value)
                group.arms.append([end, len(raw), cond])
                stack[-1] = (index, len(group.arms) - 1)
            elif kind == 'endif':
                if not stack:
                    self.malformed_conditionals += 1
                    continue
                index, arm = stack.pop()
                self.groups[index].arms[arm][1] = start
                self.groups[index].end = end
        self.malformed_conditionals += len(stack)
        self.guard_spans = self._guards()

    def _guards(self):
        guards = []
        # Scan trivia once, rather than rescanning every prefix of a large
        # amalgamation for each nested/independent conditional.
        before_clean = re.sub(
            rb'(?m)^[ \t\v\f]*#[ \t\v\f]*pragma[ \t\v\f]+once[ \t\v\f\r]*$',
            lambda m: blank(m.group()), self.clean)
        first = re.search(rb'\S', before_clean)
        first_content = first.start() if first else len(self.raw)
        last_content = len(self.clean.rstrip())
        for group in self.groups:
            if group.parents or len(group.arms) != 1:
                continue
            cond = group.arms[0][2]
            if not cond or cond[1] or not re.fullmatch(r'defined\(\w+\)', cond[0]):
                continue
            if first_content < group.start or last_content > group.end:
                continue
            name = cond[0][8:-1].encode()
            for start, end, kind, value in self.directives:
                if group.arms[0][0] <= start < group.arms[0][1] and kind == 'define' and value == name:
                    guards.append((start, end))
                    break
        return guards

    def text(self, start, end):
        parts, position = [], start
        for i in range(bisect_right(self.comment_ends, start), len(self.comments)):
            a, b = self.comments[i]
            if a >= end:
                break
            parts.extend((self.raw[position:max(position, a)], b' '))
            position = min(end, b)
        parts.append(self.raw[position:end])
        return b''.join(parts).decode('utf-8', errors='replace').strip()

    def _requirements(self, index, arm):
        requirements = {}
        for group_index, target in (*self.groups[index].parents, (index, arm)):
            for i, (_, _, cond) in enumerate(self.groups[group_index].arms[:target + 1]):
                if cond is None:
                    continue
                atom, polarity = cond
                desired = polarity if i == target else not polarity
                if atom in requirements and requirements[atom] != desired:
                    return None
                requirements[atom] = desired
        return requirements

    def _selection(self, values):
        selected = {}
        for index, group in enumerate(self.groups):
            if any(selected.get(parent) != arm for parent, arm in group.parents):
                continue
            for arm, (_, _, cond) in enumerate(group.arms):
                if cond is None or values.get(cond[0], cond[1]) == cond[1]:
                    selected[index] = arm
                    break
        return selected

    def profiles(self, limit=128):
        """Deterministic branch cover, with shared choices for repeated conditions."""
        defaults = {}
        for group in self.groups:
            cond = group.arms[0][2]
            if cond:
                defaults.setdefault(cond[0], cond[1])
        assignments, demands = [defaults], []
        for index, group in enumerate(self.groups):
            # Also inspect the path with an optional block absent. It has no
            # physical arm to count, but can restore the surrounding C syntax
            # (e.g. an extern "C" wrapper guarded by __cplusplus in a C header).
            choices = len(group.arms) + (group.arms[-1][2] is not None)
            for arm in range(choices):
                required = self._requirements(index, arm)
                if required is not None:
                    demands.append(required)
                    assignments.append({**defaults, **required})
        seen, selections = set(), []
        for assignment in assignments:
            selection = self._selection(assignment)
            identity = tuple(sorted(selection.items()))
            if identity in seen:
                continue
            seen.add(identity)
            selections.append(selection)
            if len(selections) > limit:
                break
        if len(selections) > limit:
            # Independent branches need not consume one profile each. Pack
            # compatible branch requirements when the original cover exceeds
            # the cap. Keep the existing schedule for ordinary small files.
            packed = []
            for required in sorted(demands, key=lambda r: (-len(r), tuple(sorted(r.items())))):
                for assignment in packed:
                    if all(atom not in assignment or assignment[atom] == value
                           for atom, value in required.items()):
                        assignment.update(required)
                        break
                else:
                    if len(packed) < limit:
                        packed.append(dict(required))
            seen, selections = set(), []
            for assignment in packed:
                selection = self._selection({**defaults, **assignment})
                identity = tuple(sorted(selection.items()))
                if identity not in seen:
                    seen.add(identity)
                    selections.append(selection)
        covered, profiles = set(), []
        for selection in selections:
            covered.update(selection.items())
            buf = bytearray(self.raw)
            for start, end, kind, _ in self.directives:
                if kind in {'if', 'ifdef', 'ifndef', 'elif', 'else', 'endif', 'elifdef', 'elifndef'}:
                    mask(buf, start, end)
            for index, group in enumerate(self.groups):
                for arm, (start, end, _) in enumerate(group.arms):
                    if selection.get(index) != arm:
                        mask(buf, start, end)
            for start, end in self.guard_spans:
                mask(buf, start, end)
            profiles.append(bytes(buf))
        total = sum(len(g.arms) for g in self.groups)
        return profiles, total - len(covered)


def normalize_c(raw):
    """Mask known prototype wrappers and old-style parameter lists for parsing."""
    buf = code_mask(raw)
    scan = bytearray(buf)
    for start, end, _, _ in directives(raw):
        mask(scan, start, end)
    tokens = [t for t in TOKEN.finditer(scan) if t.lastgroup not in {'comment', 'string', 'raw'}]
    match_end, stack, file_level = {}, [], set()
    brace_depth = 0
    for i, token in enumerate(tokens):
        if token.group() == b'(':
            if not stack and brace_depth == 0:
                file_level.add(i)
            stack.append(i)
        elif token.group() == b')' and stack:
            match_end[stack.pop()] = i
        elif token.group() == b'{':
            brace_depth += 1
        elif token.group() == b'}':
            brace_depth = max(0, brace_depth - 1)
    wrappers = 0
    for i, token in enumerate(tokens):
        if token.group() not in {b'__P', b'__PMT', b'PARAMS', b'PNGARG'} or i + 2 >= len(tokens):
            continue
        if tokens[i + 1].group() == tokens[i + 2].group() == b'(' and i + 1 in match_end:
            close = tokens[match_end[i + 1]]
            mask(buf, token.start(), token.end())
            mask(buf, tokens[i + 1].start(), tokens[i + 1].end())
            mask(buf, close.start(), close.end())
            wrappers += 1
    # Only bare identifier parameter lists followed by declaration statements.
    old_style = 0
    for opening, closing in match_end.items():
        # A C function definition begins at file scope, outside another
        # parenthesized expression. Without this restriction sizeof(T), calls
        # and control expressions can consume later statements as parameters.
        if opening not in file_level or opening == 0 or tokens[opening - 1].lastgroup != 'identifier':
            continue
        if tokens[opening - 1].group() in {b'sizeof', b'_Alignof', b'alignof', b'_Generic'}:
            continue
        items = tokens[opening + 1:closing]
        if not items or any(t.lastgroup != 'identifier' and t.group() != b',' for t in items):
            continue
        if any(t.group() in {b'void', b'int', b'char', b'long', b'float', b'double'} for t in items):
            continue
        if any((j % 2 == 0) != (t.lastgroup == 'identifier') for j, t in enumerate(items)):
            continue
        names = {t.group() for t in items if t.lastgroup == 'identifier'}
        after = closing + 1
        if after < len(tokens) and tokens[after].group() in {b';', b')', b',', b':', b'{', b'}', b'=', b'#'}:
            continue
        while after < len(tokens) and tokens[after].group() not in {b'{', b'}', b'=', b'#'}:
            if tokens[after].start() - tokens[closing].end() > 4096:
                break
            after += 1
        declarations = tokens[closing + 1:after]
        if after >= len(tokens) or tokens[after].group() != b'{' or not declarations:
            continue
        if not any(t.group() == b';' for t in declarations):
            continue
        if declarations[0].group() in {b';', b')', b',', b':'}:
            continue
        if not names <= {t.group() for t in declarations}:
            continue
        mask(buf, tokens[opening].end(), tokens[closing].start())
        mask(buf, tokens[closing].end(), tokens[after].start())
        old_style += 1
    return bytes(buf), wrappers, old_style


def declaration_macros(raw):
    """Find standalone uppercase declaration calls, outside directives/literals.

    Their scope is decided by the parsed placeholder. Calls in function bodies
    remain part of that body's original source, never independent file features.
    """
    safe = code_mask(raw, strings=True)
    for start, end, _, _ in directives(raw):
        mask(safe, start, end)
    found = []
    for match in re.finditer(rb'(?m)^[ \t]*([A-Z_][A-Z_0-9]*[A-Z_0-9]|SkDEBUGCODE)\s*\(', safe):
        start = match.start(1)
        opening = match.end() - 1
        depth, end = 1, opening + 1
        while end < len(safe) and depth:
            depth += (safe[end] == 40) - (safe[end] == 41)
            end += 1
        if depth:
            continue
        tail = end
        while tail < len(safe) and safe[tail] in b' \t\r':
            tail += 1
        next_code = tail
        while next_code < len(safe) and safe[next_code] in b' \t\r\n':
            next_code += 1
        if next_code < len(safe) and safe[next_code] in b'{:=':
            continue  # a function/constructor body may start on the next line
        if tail < len(safe) and safe[tail] == ord(';'):
            end = tail + 1
        elif tail < len(safe) and safe[tail] != ord('\n'):
            continue  # a real function/macro definition, initializer, etc.
        found.append((start, end, match.group(1).decode()))
    return found


def normalize_signature_macros(raw, language):
    """Known declaration annotations, masked only for syntax recognition."""
    safe = code_mask(raw, strings=True)
    for start, end, _, _ in directives(raw):
        mask(safe, start, end)
    buf, count = bytearray(raw), 0
    # These library annotations were verified in GT source declarations. The
    # parser placeholder anchors the original signature, including its macro.
    exports = rb'(?:BASE_EXPORT|UI_EXPORT|CONTENT_EXPORT|WEBKIT_EXPORT|WEBKIT_GLUE_EXPORT|WEBKIT_PLUGINS_EXPORT|WTF_EXPORT_PRIVATE|WTF_EXPORT_STRING_API|WEBCORE_TESTING|SK_API)'
    if language == 'cpp':
        for match in re.finditer(rb'(?m)^[ \t]*(' + exports + rb')\b(?=\s+(?:[A-Za-z_]|~))', safe):
            mask(buf, match.start(1), match.end(1))
            buf[match.start(1):match.start(1) + 6] = b'inline'
            count += 1
        # Pre-C++20 destructor template-ids are legal in this old corpus but
        # unsupported by the grammar. Keep their spelling in emitted text.
        for match in re.finditer(rb'~[A-Za-z_]\w*\s*(<[^<>;{}()]+>)(?=\s*\()', safe):
            mask(buf, match.start(1), match.end(1))
            count += 1
    for match in re.finditer(rb'(?<=[*\w])\s+(U_EXPORT2)\b(?=\s+[A-Za-z_]\w*(?:::\w+)*\s*\()', safe):
        mask(buf, match.start(1), match.end(1))
        count += 1
    for match in re.finditer(rb'\bNSPR_API\s*\(([^()\n]+)\)(?=\s+\**[A-Za-z_]\w*\s*\()', safe):
        mask(buf, match.start(), match.end())
        buf[match.start()] = ord('T')
        count += 1
    # libpng C headers also occur in the C++ project. Unwrap only this known
    # prototype macro here, without applying C's K&R normalization to C++.
    for match in re.finditer(rb'\bPNGARG\s*\(\s*\(', safe):
        opening = safe.index(b'(', match.start(), match.end())
        depth, end = 1, opening + 1
        while end < len(safe) and depth:
            depth += (safe[end] == 40) - (safe[end] == 41)
            end += 1
        if not depth:
            mask(buf, match.start(), opening + 1)
            mask(buf, end - 1, end)
            count += 1
    for match in re.finditer(rb'(?m)^[ \t]*(PNG_EXTERN)\b(?=\s+[A-Za-z_])', safe):
        mask(buf, match.start(1), match.end(1))
        buf[match.start(1):match.start(1) + 6] = b'extern'
        count += 1
    for match in re.finditer(rb'\bPNG_EXPORT\s*\(([^,()\n]+),\s*([A-Za-z_]\w*)\s*\)', safe):
        mask(buf, match.start(), match.start(2))
        buf[match.start()] = ord('T')
        mask(buf, match.end(2), match.end())
        count += 1
    for match in re.finditer(rb'\(\s*(PNGAPI)\b(?=\s*\*)', safe):
        mask(buf, match.start(1), match.end(1))
        count += 1
    for match in re.finditer(rb'\)\s+(PNG_PRIVATE|PNG_DEPRECATED)\b(?=\s*;)', safe):
        mask(buf, match.start(1), match.end(1))
        count += 1
    # SQLite's amalgamation defines these as visibility/storage annotations.
    # Keep their physical spelling in output; only the parser sees the mask.
    for match in re.finditer(rb'(?m)^[ \t]*(SQLITE_API|SQLITE_PRIVATE)\b(?=\s+[A-Za-z_])', safe):
        mask(buf, match.start(1), match.end(1))
        placeholder = b'extern' if match.group(1) == b'SQLITE_API' else b'static'
        buf[match.start(1):match.start(1) + len(placeholder)] = placeholder
        count += 1
    if language == 'c':
        # libjpeg's storage/return-type wrappers are not standalone declarations.
        pattern = rb'\b(?:LOCAL|GLOBAL|METHODDEF|EXTERN)\s*\(([^()\n]+)\)(?=\s+\**[A-Za-z_]\w*\s*\()'
        for match in re.finditer(pattern, safe):
            # Anchor a type placeholder at the original beginning so the
            # emitted signature includes the complete wrapper, not its tail.
            mask(buf, match.start(), match.end())
            buf[match.start()] = ord('T')
            count += 1
    else:
        pattern = rb'\b(?:class|struct|union)\s+([A-Z_][A-Z_0-9]*(?:EXPORT|API)(?:_PRIVATE)?)\s+[A-Za-z_]\w*'
        for match in re.finditer(pattern, safe):
            mask(buf, match.start(1), match.end(1))
            count += 1
        # These wrappers affect linkage/visibility, not the source-view unit.
        for match in re.finditer(rb'(?m)^[ \t]*(G_BEGIN_DECLS|G_END_DECLS)\b[ \t]*$', safe):
            mask(buf, match.start(), match.end())
            count += 1
        for match in re.finditer(rb'\bNON_EXPORTED_BASE\s*\(([^()\n]+)\)', safe):
            mask(buf, match.start(), match.start(1))
            mask(buf, match.end(1), match.end())
            count += 1
        # Only method suffixes: variables/parameters named FINAL or OVERRIDE
        # must remain intact. Their original spelling is emitted unchanged.
        for suffix in re.finditer(rb'\)(?:\s+(?:const|volatile|noexcept|OVERRIDE|FINAL))*\s*(?=[;{=])', safe):
            for annotation in re.finditer(rb'\b(?:OVERRIDE|FINAL)\b', suffix.group()):
                mask(buf, suffix.start() + annotation.start(), suffix.start() + annotation.end())
                count += 1
    return bytes(buf), count


def normalize_enum_directives(raw):
    """Hide enum-local directives from the grammar, without expanding includes.

    The renderer retains original enum declarations, moves function-like macro
    definitions to members, and excludes include/undef lines from file text.
    """
    spans = directives(raw)
    if not spans or b'enum' not in raw:
        return raw
    safe = code_mask(raw, strings=True)
    for start, end, _, _ in spans:
        mask(safe, start, end)
    stack, pairs = [], {}
    for match in re.finditer(rb'[{}]', safe):
        if match.group() == b'{':
            stack.append(match.start())
        elif stack:
            pairs[stack.pop()] = match.end()
    ranges = [(m.end() - 1, pairs[m.end() - 1])
              for m in re.finditer(rb'\benum\b[^{};=]*\{', safe)
              if m.end() - 1 in pairs]
    buf = bytearray(raw)
    for start, end, _, _ in spans:
        if any(a < start < b for a, b in ranges):
            mask(buf, start, end)
    return bytes(buf)


def function_macro_spans(raw, spans=None):
    """Physical logical-line spans; comments must not truncate macro bodies."""
    return [(raw.index(b'#', start, end), end)
            for start, end, kind, value in (directives(raw) if spans is None else spans)
            if kind == 'define' and re.match(rb'[A-Za-z_]\w*\(', value)]


def mask_function_macros(raw):
    # Macro bodies are preprocessing tokens, not ordinary C/C++ declarations.
    # Their full original logical lines are emitted separately as members.
    buf = bytearray(raw)
    for start, end in function_macro_spans(raw):
        mask(buf, start, end)
    return bytes(buf)


def mask_macros(raw, macros):
    buf = bytearray(raw)
    for start, end, _ in macros:
        if not bytes(buf[start:end]).strip():
            continue
        mask(buf, start, end)
        # A declaration parses at file, class and block scope. The original
        # macro call is restored only at the declaration scope found by AST.
        placeholder = b'int M;' if end - start >= 6 else b'M m;'
        if b'\n' in buf[start:start + len(placeholder)] or b'\r' in buf[start:start + len(placeholder)]:
            # A short macro name can put a newline inside the placeholder.
            # Single-letter tokens remain valid even when separated by lines.
            positions = [i for i in range(start, end) if buf[i] not in b'\r\n']
            for position, value in zip(positions, b'T t;'):
                buf[position] = value
        else:
            buf[start:start + len(placeholder)] = placeholder
    return bytes(buf)


def brace_ends(raw):
    """Lexical brace pairs in one profile, excluding directives and literals."""
    scan = bytearray(raw)
    for start, end, _, _ in directives(raw):
        mask(scan, start, end)
    stack, pairs = [], {}
    for token in TOKEN.finditer(scan):
        if token.lastgroup != 'punct':
            continue
        if token.group() == b'{':
            stack.append(token.start())
        elif token.group() == b'}' and stack:
            pairs[stack.pop()] = token.end()
    return pairs
