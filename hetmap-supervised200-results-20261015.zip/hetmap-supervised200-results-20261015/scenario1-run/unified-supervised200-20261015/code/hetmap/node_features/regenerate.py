"""Audited regeneration of scenario-1 or legacy Java-parser embeddings."""
from __future__ import annotations

import argparse
import hashlib
import importlib.metadata
import json
from pathlib import Path

import torch

from . import unixcoder_emb as emb
from .data_loader import load_project, _PROJECT_REGISTRY, _DATASETS_DIR
from .source_views import EXTRACTION_VERSION, extract_source_views, language_for


def digest(path):
    h = hashlib.sha256()
    with open(path, "rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def regenerate_project(hetmap_name, arc_key, device, project_dir, pkg_name=False,
                       frozen_only=False, *, output_dir=None, model_path=None,
                       source_root=None, datasets_dir=None, extraction="scenario1",
                       language_overrides=None, audit_only=False):
    output_dir = Path(output_dir or emb.OUTPUT_DIR)
    model_path = Path(model_path or emb.MODEL_PATH)
    sub = emb._REPOS[arc_key]
    source_root = Path(source_root) if source_root else Path(project_dir) / (sub or "")
    data_root = Path(datasets_dir) if datasets_dir else _DATASETS_DIR
    df, deps = load_project(arc_key, project_dir, source_root=source_root, datasets_dir=data_root)
    keys = df["dep_key"].tolist()
    rows = []
    for key in keys:
        raw = (source_root / key.lstrip("/\\")).read_bytes()
        source = raw.decode("utf-8", errors="replace")
        prefix = str(Path(key).with_suffix("")) if pkg_name else Path(key).stem
        language = language_for(key, arc_key, language_overrides)
        views = extract_source_views(source, language, prefix, legacy_java=extraction == "legacy-java")
        rows.append({"key": key, "source_sha256": hashlib.sha256(raw).hexdigest(),
                     "source_language": language, "decode_replacements": source.count("\ufffd"),
                     **views.to_dict()})

    packages = ["torch", "transformers", "numpy", "tree-sitter", "tree-sitter-java", "tree-sitter-c", "tree-sitter-cpp"]
    spec = {"project": hetmap_name, "extraction": extraction, "version": EXTRACTION_VERSION,
            "pkg_name": pkg_name, "source_root": str(source_root.resolve()),
            "dataset_sha256": {name: digest(data_root / name) for name in _PROJECT_REGISTRY[arc_key][:2]},
            "code_sha256": {name: digest(Path(__file__).parent / name) for name in
                            ["source_views.py", "c_family_frontend.py", "c_family_views.py",
                             "unixcoder_emb.py", "regenerate.py", "data_loader.py"]},
            "packages": {name: importlib.metadata.version(name) for name in packages},
            "input_sha256": hashlib.sha256(json.dumps(rows, sort_keys=True).encode()).hexdigest(),
            "model_sha256": {} if audit_only else {p.name: digest(p) for p in sorted(model_path.iterdir())
                         if p.is_file() and p.suffix in {".bin", ".safetensors", ".json", ".txt"}},
            "settings": {name: getattr(emb, name) for name in ["TRUNC_MAX", "CHUNK_SIZE", "STRIDE", "BATCH_SIZE",
                         "LR", "EPOCHS", "FREEZE_LAYERS", "TEMPERATURE", "PAIRS_PER_FILE", "HOP2_PROB", "TOPK_N2", "SEED"]}}
    fingerprint = hashlib.sha256(json.dumps(spec, sort_keys=True).encode()).hexdigest()
    output_dir.mkdir(parents=True, exist_ok=True)
    manifest_path = output_dir / f"{hetmap_name}_manifest.json"
    if manifest_path.exists():
        previous = json.loads(manifest_path.read_text())
        if previous["fingerprint"] != fingerprint:
            raise FileExistsError(f"Inputs/settings differ from {manifest_path}; choose a fresh --output-dir")
    elif list(output_dir.glob(f"{hetmap_name}_*_emb.npy")):
        raise FileExistsError("Unversioned embeddings found; choose a fresh --output-dir")
    tags = ["file_pkg" if pkg_name else "file", "member"]
    if not frozen_only:
        tags += [tag + "_ft" for tag in tags[:]]
    if not audit_only and manifest_path.exists() and previous.get("complete") and all(
            (output_dir / f"{hetmap_name}_{tag}_{suffix}").exists()
            for tag in tags for suffix in ("emb.npy", "keys.txt")):
        for name, expected in previous["outputs"].items():
            if digest(output_dir / name) != expected:
                raise ValueError(f"Cached output checksum mismatch: {name}; choose a fresh --output-dir")
        print(f"[{hetmap_name}] verified manifest; embeddings already complete", flush=True)
        return
    summary = {"files": len(rows), "parse_error_files": sum(r["has_error"] for r in rows),
               "empty_file_views": sum(r["file_content_empty"] for r in rows),
               "empty_member_views": sum(r["member_content_empty"] for r in rows),
               "raw_parse_error_files": sum(r["raw_has_error"] for r in rows),
               "outside_body_error_files": sum(r["outside_body_error_nodes"] > 0 for r in rows),
               "uncovered_conditional_branches": sum(r["conditional_branches_uncovered"] for r in rows),
               "malformed_conditionals": sum(r["malformed_conditionals"] for r in rows),
               "declaration_macro_files": sum(bool(r["declaration_macros"]) for r in rows)}
    manifest = {"fingerprint": fingerprint, "spec": spec, "summary": summary, "complete": False}

    def write_audit():
        with (output_dir / f"{hetmap_name}_inputs.jsonl").open("w") as stream:
            for row in rows:
                stream.write(json.dumps(row, ensure_ascii=False) + "\n")
        manifest_path.write_text(json.dumps(manifest, indent=2) + "\n")

    write_audit()
    print(f"[{hetmap_name}] {extraction}: {summary}", flush=True)
    if audit_only:
        return
    tok, model = emb._load_model(model_path)
    model.to(device).eval()
    file_texts = [r["file_text"] for r in rows]
    member_texts = [r["member_text"] or "[no methods]" for r in rows]
    for row, member_text in zip(rows, member_texts):
        row["file_token_count"] = len(tok(row["file_text"], truncation=False)["input_ids"])
        row["file_truncated"] = row["file_token_count"] > emb.TRUNC_MAX
        row["member_token_count"] = len(tok(member_text, truncation=False)["input_ids"])
    summary["file_truncated"] = sum(r["file_truncated"] for r in rows)
    manifest["device"] = str(device)
    manifest["gpu"] = torch.cuda.get_device_name() if str(device).startswith("cuda") else None
    write_audit()

    def save(tag, texts, encoder):
        p = output_dir / f"{hetmap_name}_{tag}_emb.npy"
        k = output_dir / f"{hetmap_name}_{tag}_keys.txt"
        if not (p.exists() and k.exists()):
            emb._save(encoder(texts, tok, model, device), keys, p, k)
    file_tag = tags[0]
    save(file_tag, file_texts, emb._encode_truncated)
    save("member", member_texts, emb._encode_chunked)
    if not frozen_only:
        emb._finetune(file_texts, keys, deps, tok, model, device, hetmap_name)
        save(file_tag + "_ft", file_texts, emb._encode_truncated)
        save("member_ft", member_texts, emb._encode_chunked)
    manifest["complete"] = True
    manifest["outputs"] = {p.name: digest(p) for tag in tags for suffix in ("emb.npy", "keys.txt")
                           for p in [output_dir / f"{hetmap_name}_{tag}_{suffix}"]}
    manifest_path.write_text(json.dumps(manifest, indent=2) + "\n")
    model.cpu()
    del model, tok
    if torch.cuda.is_available():
        torch.cuda.empty_cache()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--project", choices=list(emb.PROJECTS), required=True)
    parser.add_argument("--project-dir", default="data/projects")
    parser.add_argument("--source-root", type=Path, help="Exact root containing paths listed in the CSV")
    parser.add_argument("--datasets-dir", type=Path)
    parser.add_argument("--model-path", type=Path, default=emb.MODEL_PATH)
    parser.add_argument("--output-dir", type=Path, required=True, help="Fresh/versioned directory; old caches are rejected")
    parser.add_argument("--extraction", choices=["scenario1", "legacy-java"], default="scenario1")
    parser.add_argument("--language-overrides", type=Path, help="JSON mapping exact file keys to c/cpp/java")
    parser.add_argument("--pkg-name", action="store_true")
    parser.add_argument("--frozen-only", action="store_true")
    parser.add_argument("--audit-only", action="store_true", help="Extract and audit without loading the encoder")
    parser.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    args = parser.parse_args()
    overrides = json.loads(args.language_overrides.read_text()) if args.language_overrides else None
    regenerate_project(args.project, emb.PROJECTS[args.project], args.device, args.project_dir,
                       args.pkg_name, args.frozen_only, output_dir=args.output_dir, model_path=args.model_path,
                       source_root=args.source_root, datasets_dir=args.datasets_dir, extraction=args.extraction,
                       language_overrides=overrides, audit_only=args.audit_only)


if __name__ == "__main__":
    main()
