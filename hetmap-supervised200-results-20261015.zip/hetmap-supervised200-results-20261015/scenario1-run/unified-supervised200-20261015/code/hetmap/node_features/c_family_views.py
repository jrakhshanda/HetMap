"""Merge syntax recovered across conditional profiles by physical source span."""
import re

from .c_family_frontend import Source, normalize_c, normalize_signature_macros, normalize_enum_directives, function_macro_spans, mask_function_macros, declaration_macros, mask_macros, brace_ends, mask


TYPES = {'class_specifier', 'struct_specifier', 'union_specifier', 'enum_specifier'}
CONTAINERS = {'translation_unit', 'declaration_list', 'field_declaration_list',
              'linkage_specification', 'preproc_if', 'preproc_ifdef', 'preproc_else',
              'preproc_elif', 'preproc_elifdef'}


def extract(raw, language, parser, declarator, constructor):
    source = Source(raw)
    define_ends = {raw.index(b'#', a, b): b for a, b, kind, _ in source.directives if kind == 'define'}
    initial_tree = parser.parse(raw)
    raw_error = initial_tree.root_node.has_error
    # Masking declarations also keeps annotation/registration macros from
    # destroying surrounding class boundaries. Their original text is restored.
    initial = mask_function_macros(raw)
    initial, wrappers, old_style = normalize_c(initial) if language == 'c' else (initial, 0, 0)
    initial, signature_macros = normalize_signature_macros(initial, language)
    initial = normalize_enum_directives(initial)
    initial_macros = declaration_macros(initial)
    initial = mask_macros(initial, initial_macros)
    tree = parser.parse(initial)
    # Error-free original structure already represents both preprocessor arms.
    # Otherwise select syntactic branches so incompatible signatures/braces do
    # not get parsed together. The emitted bodies still contain original arms.
    if tree.root_node.has_error:
        profiles, uncovered = source.profiles()
    else:
        profiles, uncovered = [raw], 0

    scopes = {None: {'header': '', 'suffix': '', 'children': set(), 'start': -1}}
    files, members = {}, {}
    errors, missing = set(), set()
    body_errors, outside_errors = set(), set()
    opaque = {}
    normalizations = set()
    wrapper_spans = set()
    function_bodies = set()
    function_headers = set()
    diagnostics = {}
    extended_bodies = set()
    record_files = True

    def add_file(parent, key, start, end, text):
        if not text or not record_files:
            return
        previous = files.get(key)
        if previous is None or end > previous['end']:
            files[key] = {'start': start, 'end': end, 'text': text}
        scopes[parent]['children'].add(('file', key))

    def add_member(key, start, end, text):
        previous = members.get(key)
        if previous is None or start < previous['start'] or end > previous['end']:
            members[key] = {'start': start, 'end': end, 'text': text}

    def enum_text(start, end):
        pieces, position = [], start
        for a, b, kind, value in source.directives:
            if not start <= a < b <= end:
                continue
            function_macro = kind == 'define' and re.match(rb'[A-Za-z_]\w*\(', value)
            if function_macro:
                begin = raw.index(b'#', a, b)
                add_member(('macro_definition', begin), begin, b, source.text(begin, b))
            if function_macro or kind in {'include', 'include_next', 'undef'}:
                pieces.append(source.text(position, a))
                position = b
        pieces.append(source.text(position, end))
        return '\n'.join(piece for piece in pieces if piece)

    for start, end in function_macro_spans(raw, source.directives):
        add_member(('macro_definition', start), start, end, source.text(start, end))

    def scope(node, body, parent, start=None, end=None):
        start = node.start_byte if start is None else start
        end = node.end_byte if end is None else end
        key = (body.start_byte, body.end_byte)
        header = source.text(start, body.start_byte)
        suffix = source.text(body.end_byte, end)
        if key not in scopes:
            scopes[key] = {'header': header, 'suffix': suffix, 'children': set(), 'start': start}
        elif start < scopes[key]['start']:
            scopes[key].update(header=header, suffix=suffix, start=start)
        scopes[parent]['children'].add(('scope', key))
        return key

    def render(node, parent=None, class_name=None, template_start=None, recovered=False):
        kind = node.type
        begin = template_start if template_start is not None else node.start_byte
        if node.start_byte in macro_by_start and kind in {'declaration', 'field_declaration', 'expression_statement'}:
            end, name = macro_by_start[node.start_byte]
            # These declarations are kept as physical, unexpanded metadata. No
            # generated method body is invented and the uncertainty is audited.
            category = 'type_declaration' if re.match(r'IPC_(?:SYNC_MESSAGE|MESSAGE_(?:CONTROL|ROUTED)|STRUCT_TRAITS|ENUM_TRAITS)', name) else 'opaque_declaration'
            opaque[node.start_byte] = {'name': name, 'start_byte': node.start_byte,
                                      'end_byte': end, 'classification': category,
                                      'scope': 'class' if class_name else 'file'}
            add_file(parent, ('macro', node.start_byte), node.start_byte, end,
                     source.text(node.start_byte, end))
            return
        if kind in CONTAINERS:
            for child in node.named_children:
                render(child, parent, class_name, template_start, recovered)
            return
        if kind == 'ERROR':
            # Never promote ambiguous declarations from a damaged body into
            # file state. Only independently recognized structured nodes are
            # safe to recover without a reliable surrounding scope.
            for child in node.named_children:
                if child.type in TYPES | {'function_definition', 'namespace_definition',
                                          'template_declaration', 'type_definition',
                                          'alias_declaration', 'ERROR'}:
                    render(child, parent, class_name, template_start, True)
            return
        if kind == 'namespace_definition':
            body = node.child_by_field_name('body')
            if body:
                container = scope(node, body, parent)
                render(body, container)
            return
        if kind == 'template_declaration':
            parameters = node.child_by_field_name('parameters')
            children = [c for c in node.named_children if c != parameters and c.type != 'requires_clause']
            if children:
                render(children[-1], parent, class_name, begin, recovered)
            return
        if kind == 'expression_statement' and language == 'cpp':
            # At declaration scope the grammar can interpret T& f(U* = 0)
            # as a binary/call expression. A storage specifier disambiguates
            # it without changing the emitted source or promoting variables.
            probe = parser.parse(b'extern ' + node.text).root_node
            stack, acceptable = [probe], True
            while stack:
                child = stack.pop()
                if child.is_missing:
                    acceptable = False
                if child.type == 'ERROR' and not (
                        child.text in {b'*', b'&', b'&&'} and child.parent is not None
                        and child.parent.type == 'optional_parameter_declaration'
                        and child.parent.child_by_field_name('default_value') is not None):
                    acceptable = False
                stack.extend(child.children)
            # The grammar also flags the abstract pointer in U* = 0. Permit
            # only that precise parameter error; keep original diagnostics.
            if acceptable and len(probe.named_children) == 1:
                declaration = probe.named_children[0]
                if declaration.type == 'declaration' and any(
                        declarator(d)[1] == 'function_declarator'
                        for d in declaration.children_by_field_name('declarator')):
                    add_member(('prototype', node.start_byte, 'disambiguated'),
                               begin, node.end_byte, source.text(begin, node.end_byte))
            return
        if kind in TYPES:
            body = node.child_by_field_name('body')
            if body is None or kind == 'enum_specifier':
                add_file(parent, (kind, node.start_byte), begin, node.end_byte,
                         enum_text(begin, node.end_byte) if kind == 'enum_specifier' else source.text(begin, node.end_byte))
            else:
                container = scope(node, body, parent, begin)
                name = node.child_by_field_name('name')
                render(body, container, name.text.decode('utf-8', errors='replace') if name else class_name)
            return
        if kind == 'function_definition':
            body = node.child_by_field_name('body')
            if body is None:
                text = source.text(begin, node.end_byte)
                if constructor(node, class_name):
                    add_file(parent, ('constructor', node.start_byte), begin, node.end_byte, text)
                else:
                    add_member(('definition', node.start_byte, node.end_byte), begin, node.end_byte, text)
                return
            end = max(node.end_byte, braces.get(body.start_byte, body.end_byte))
            body_end = max(body.end_byte, braces.get(body.start_byte, body.end_byte))
            function_bodies.add((body.start_byte, body_end))
            function_headers.add((begin, body.start_byte))
            if constructor(node, class_name):
                excerpt = source.text(body.start_byte, body_end)
                excerpt = excerpt[:200].rstrip() + ('...' if len(excerpt) > 200 else '')
                add_file(parent, ('constructor', body.start_byte), begin, end,
                         source.text(begin, body.start_byte) + '\n' + excerpt)
            else:
                text = source.text(begin, end)
                if template_start is not None:
                    text = source.text(begin, node.start_byte) + '\n' + source.text(node.start_byte, end)
                add_member(('definition', body.start_byte), begin, end,
                           text)
            return
        if kind == 'friend_declaration':
            for child in node.named_children:
                if child.type in {'declaration', 'function_definition', 'template_declaration'}:
                    render(child, parent, class_name, template_start, recovered)
            return
        if kind in {'type_definition', 'alias_declaration'}:
            typ = node.child_by_field_name('type')
            if typ is not None and typ.type == 'type_descriptor':
                typ = typ.child_by_field_name('type')
            body = typ.child_by_field_name('body') if typ is not None else None
            if typ is not None and typ.type in TYPES - {'enum_specifier'} and body is not None:
                container = scope(typ, body, parent, begin, node.end_byte)
                name = typ.child_by_field_name('name')
                render(body, container, name.text.decode('utf-8', errors='replace') if name else class_name)
            else:
                text = enum_text(begin, node.end_byte) if typ is not None and typ.type == 'enum_specifier' else source.text(begin, node.end_byte)
                add_file(parent, (kind, node.start_byte), begin, node.end_byte, text)
            return
        if kind in {'declaration', 'field_declaration', 'template_instantiation'}:
            decls = node.children_by_field_name('declarator')
            typ = node.child_by_field_name('type')
            body = typ.child_by_field_name('body') if typ is not None else None
            if typ is not None and typ.type in TYPES - {'enum_specifier'} and body is not None:
                container = scope(typ, body, parent, begin, node.end_byte)
                name = typ.child_by_field_name('name')
                render(body, container, name.text.decode('utf-8', errors='replace') if name else class_name)
                return
            if not decls:
                for child in node.named_children:
                    if child.type in TYPES:
                        render(child, parent, class_name, template_start, recovered)
                return
            head = (enum_text(begin, decls[0].start_byte) if typ is not None and typ.type == 'enum_specifier'
                    else source.text(begin, decls[0].start_byte))
            for index, decl in enumerate(decls):
                name, operator = declarator(decl)
                end = decls[index + 1].start_byte if index + 1 < len(decls) else node.end_byte
                tail = source.text(decl.start_byte, end).rstrip().rstrip(',;').rstrip()
                text = (head + ' ' + tail).strip() + ';'
                if operator == 'function_declarator' and not constructor(node, class_name):
                    add_member(('prototype', decl.start_byte, name), begin, end, text)
                elif not recovered:
                    add_file(parent, ('declaration', decl.start_byte), begin, end, text)
            return
        if kind in {'preproc_def', 'preproc_function_def'}:
            if any(a <= node.start_byte < b for a, b in source.guard_spans):
                return
            end = define_ends.get(node.start_byte, node.end_byte)
            if kind == 'preproc_function_def':
                add_member(('macro_definition', node.start_byte), node.start_byte, end,
                           source.text(node.start_byte, end))
            else:
                add_file(parent, ('define', node.start_byte), node.start_byte, end,
                         source.text(node.start_byte, end))

    # Keep error-free operation nodes from the initial physical-source tree.
    # A bounded set of profiles must not discard a sound operation merely
    # because its preprocessor arm appears late in a very large file. Do not
    # use this fallback to promote recovered declarations into file state.
    def original_members(node, class_name=None, template_start=None):
        if node.type == 'template_declaration':
            parameters = node.child_by_field_name('parameters')
            children = [c for c in node.named_children if c != parameters and c.type != 'requires_clause']
            if children:
                original_members(children[-1], class_name, node.start_byte)
            return
        if node.type == 'function_definition':
            if not node.has_error and not constructor(node, class_name):
                render(node, class_name=class_name, template_start=template_start)
            return
        if node.type == 'preproc_function_def':
            if not node.has_error:
                render(node, class_name=class_name)
            return
        if node.type in {'declaration', 'field_declaration'} and not node.has_error:
            if any(declarator(d)[1] == 'function_declarator'
                   for d in node.children_by_field_name('declarator')):
                if not constructor(node, class_name):
                    render(node, class_name=class_name, template_start=template_start)
                return
        if node.type in TYPES:
            template_start = None
            name = node.child_by_field_name('name')
            if name:
                class_name = name.text.decode('utf-8', errors='replace')
        for child in node.named_children:
            original_members(child, class_name, template_start)

    if tree.root_node.has_error:
        braces = {}
        macro_by_start = {a: (b, name) for a, b, name in initial_macros}
        record_files = False
        original_members(tree.root_node)
        record_files = True

    for profile in profiles:
        prepared = mask_function_macros(profile)
        prepared, count, old = normalize_c(prepared) if language == 'c' else (prepared, 0, 0)
        prepared, signature_count = normalize_signature_macros(prepared, language)
        prepared = normalize_enum_directives(prepared)
        signature_macros = max(signature_macros, signature_count)
        if count:
            wrapper_spans.add(count)
        if old:
            normalizations.add(old)
        # Normalize K&R signatures before finding macro calls: an uppercase
        # function name followed by parameter declarations is still a function.
        macros = declaration_macros(prepared)
        macro_by_start = {a: (b, name) for a, b, name in macros}
        prepared = mask_macros(prepared, macros)
        tree = parser.parse(prepared)
        root = tree.root_node
        braces = brace_ends(profile) if root.has_error else {}
        skeleton = bytearray(prepared)
        masked_body = False
        stack = [(root, False)]
        while stack:
            node, inside_body = stack.pop()
            if node.type == 'ERROR' or node.is_missing:
                identity = (node.start_byte, node.end_byte, node.type)
                (missing if node.is_missing else errors).add(identity)
                (body_errors if inside_body else outside_errors).add(identity)
                diagnostics[identity] = {'start_byte': node.start_byte, 'end_byte': node.end_byte,
                                         'kind': node.type, 'missing': node.is_missing,
                                         'line': node.start_point.row + 1,
                                         'context': 'inside_function_body' if inside_body else 'outside_function_body'}
            body = node.child_by_field_name('body') if node.type == 'function_definition' else None
            if body is not None and body.start_byte in braces:
                end = braces[body.start_byte]
                # A parser error inside an ordinary body must not turn the
                # remainder into global state. Trust the recognized signature
                # and lexically balanced braces, then parse its empty skeleton.
                if end > body.end_byte:
                    extended_bodies.add((body.start_byte, end))
                mask(skeleton, body.start_byte + 1, end - 1)
                masked_body = True
            stack.extend((child, inside_body or child == body) for child in node.children)
        if masked_body:
            skeleton_tree = parser.parse(bytes(skeleton))
            root = skeleton_tree.root_node
        render(root)

    # A fragment recovered as a file declaration in one profile must never win
    # over a recognized operation body in another profile (conditional braces).
    for key, value in list(files.items()):
        if any(a <= value['start'] and value['end'] <= b for a, b in function_bodies):
            del files[key]
    blocked_scopes = {key for key in scopes if key is not None and
                      any(a <= key[0] and key[1] <= b for a, b in function_bodies)}
    def scope_text(key):
        node = scopes[key]
        children = []
        for kind, child in node['children']:
            if kind == 'file' and child in files:
                children.append((files[child]['start'], files[child]['text']))
            elif kind == 'scope' and child not in blocked_scopes:
                children.append((scopes[child]['start'], scope_text(child)))
        content = '\n'.join(text for _, text in sorted(children) if text)
        if key is None:
            return content
        # An empty class is meaningful type information; empty namespaces are not.
        if not content and node['header'].lstrip().startswith('namespace'):
            return ''
        return node['header'] + ' {\n' + content + '\n}' + node['suffix']

    # Names can occur in different declarations; deduplicate physical spans, not
    # strings, so overloaded methods and independent identical bodies survive.
    # An old-style definition may look like a prototype in the unnormalized
    # fallback tree. Once a profile recovers its body, that same physical
    # signature is part of the definition, not a second member fragment.
    member_items = sorted((v for key, v in members.items() if not any(
        a <= v['start'] and v['end'] <= b for a, b in function_bodies)
        and not (key[0] == 'prototype' and any(
            a <= v['start'] and v['end'] <= b for a, b in function_headers))),
        key=lambda item: (item['start'], item['end']))
    # Classify errors against final recovered body boundaries, since the
    # initial tree may have ended a body prematurely.
    body_errors, outside_errors = set(), set()
    for identity, diagnostic in diagnostics.items():
        inside = any(a <= diagnostic['start_byte'] and diagnostic['end_byte'] <= b
                     for a, b in function_bodies)
        diagnostic['context'] = 'inside_function_body' if inside else 'outside_function_body'
        (body_errors if inside else outside_errors).add(identity)
    return {
        'content': scope_text(None), 'member_text': '\n\n'.join(v['text'] for v in member_items),
        'member_fragments': len(member_items), 'has_error': bool(errors or missing),
        'error_nodes': len(errors), 'missing_nodes': len(missing), 'raw_has_error': raw_error,
        'prototype_wrappers_normalized': max(wrapper_spans, default=wrappers),
        'old_style_definitions_normalized': max(normalizations, default=old_style),
        'conditional_profiles': len(profiles), 'conditional_branches_uncovered': uncovered,
        'malformed_conditionals': source.malformed_conditionals,
        'body_error_nodes': len(body_errors), 'outside_body_error_nodes': len(outside_errors),
        'declaration_macros': [opaque[k] for k in sorted(opaque) if ('macro', k) in files],
        'parse_diagnostics': [diagnostics[k] for k in sorted(diagnostics)],
        'member_source_spans': [[v['start'], v['end']] for v in member_items],
        'function_bodies_extended': len(extended_bodies),
        'signature_macros_normalized': signature_macros,
    }
