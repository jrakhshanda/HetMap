# Unified supervised-200 HetMap rerun

Training job **1190** uses eight A100 GPUs, four on each node. CPU analysis job **1191** depends on successful training. The 21-case full-training preflight (job1189) matched exactly between both nodes, including initial/final weights, metrics, and Chrome FFM. All 130 frozen input conditions passed graph and feature checks.

## Fixed design

- Ten systems, including ArgoUML; 100 existing canonical splits (0–99).
- RQ1/RQ3: W2V, N2V, UXC-ZS, UXC-FT. RQ2 retains its existing W2V, N2V, UXC-FT scope.
- Exactly 200 Adam epochs, lr0.001, zero dropout, initial labeled files only. No pseudo-labeling or early stopping. Unlabeled features/edges remain available transductively.
- Same frozen caches, with common row-L2 normalization of file/member embeddings. Existing folder features remain binary. W2V retains its previously defined aggregated file view in F/FF and separate filename/member views in FM/FFM. N2V remains the selected original RQ1/RQ2 realization, including uploaded Chrome; no embeddings are regenerated.
- Dependencies merged per ordered endpoint node-type pair, restricted to different owner files, deduplicated. Folder hierarchy and containment remain distinct and unchanged.
- RQ2: HGT F/FM/FF/FFM, directed dependencies.
- RQ3: HGT, original residual/LayerNorm GAT, neighbor MLP; off, directed, and undirected conditions. Undirected adds reverse edges then deduplicates. No dependency self-loops or automatic GAT self-loops.
- Neighbor MLP consumes `[x,mean(incoming neighbors)]`; off uses `[x,0]` and is exactly the RQ1 predictor. One identical initialized model state is loaded for all three conditions within each model/system/representation/split. HGT/GAT off keeps own-feature processing but has no dependency edges.

## Fit accounting

RQ3 has 36,000 fits (10 systems ×4 representations ×3 models ×3 conditions ×100 splits). RQ1 reuses its 4,000 neighbor-MLP off fits. RQ2 reuses 3,000 directed HGT F fits and adds 9,000 FM/FF/FFM fits. Total: **45,000 distinct production fits**. Preflight fits are separate and are not selected as production scores.

## Storage and validation

Remote root: `/shared/hetmap/unified-supervised200-20261015`.

Each run group saves `initial.pt`; each condition saves final checkpoint, predictions, final and diagnostic epoch100 logits, training-loss snapshots, metrics, receipt, and independent metric/checkpoint-replay validation. Only epoch200 scores enter the primary exports. Code, raw caches, prepared inputs, graph construction and split provenance are hash-checked. Existing experiment results and paper sources are unchanged.

Watch Slurm jobs1190/1191, `logs/full-1190.out`, `outputs/node-{0,1}-status.json`, and `outputs/tasks/*.json`. Completion requires `outputs/analysis/validation.json`, not just disappearance from the queue.

The final CPU job exports `long-format.csv`, `rq1-per-run.csv`, `rq2-per-run.csv`, `rq3-per-run.csv`, medians, and RQ3 paired contrasts. RQ selections overlap intentionally through exact reuse. Statistical tables, directory-error summaries, and manuscript integration can be generated from these predictions after validation; no legacy statistics are silently carried over.

Exact protocol: `protocol.json`. Source selection: `source-provenance.json`. Input preparation: `preparation.json`. Cross-node replay: `launch-gate.json`. Launch: `launch.json`.
