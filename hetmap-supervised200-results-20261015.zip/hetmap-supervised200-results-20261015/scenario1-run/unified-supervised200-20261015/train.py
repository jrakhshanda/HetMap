import time,socket,copy
import pandas as pd
from sklearn.metrics import f1_score
from common import *

def validate(out,meta,truth,test,gpu_data,kind,model,initial_hash):
 receipt=json.loads((out/'receipt.json').read_text());assert receipt['complete'] and receipt['protocol_sha256']==sha(ROOT/'protocol.json')
 for name,h in receipt['sha256'].items():assert sha(out/name)==h,name
 row=json.loads((out/'metrics.json').read_text());assert row['initial_weights_hash']==initial_hash and row['epochs']==200
 pred=pd.read_csv(out/'predictions.csv.gz');assert pred.file_path.tolist()==np.array(meta['files'])[test].tolist()
 assert pred.true_module.tolist()==[meta['classes'][y] for y in truth[test]]
 with np.load(out/'logits.npz') as z:final=z['final'];assert np.isfinite(final).all()
 predicted=final[test].argmax(1);assert pred.pred_module.tolist()==[meta['classes'][p] for p in predicted]
 for avg in ['macro','micro']:
  kw=dict(labels=np.unique(truth[test]),zero_division=0) if avg=='macro' else {}
  assert abs(row[f'f1_{avg}']-100*f1_score(truth[test],predicted,average=avg,**kw))<1e-8
 model.load_state_dict(torch.load(out/'model.pt',map_location='cuda',weights_only=True));model.eval()
 assert digest(model)==row['final_weights_hash']
 with torch.no_grad():assert np.array_equal(logits(model,gpu_data,kind).cpu().numpy(),final)
 save(out/'validation.json',dict(complete=True,metrics_checked=2,checkpoint_replay_checked=True,protocol_sha256=sha(ROOT/'protocol.json')))
 return row

def fit_group(task,run,loaded,base=None):
 meta,ref,g=loaded;kind=task['model'];conditions=task['conditions'];group=group_path(task,run,base)
 group.mkdir(parents=True,exist_ok=True)
 seed(42+run);model=make_model(kind,g,len(meta['classes']));initial_hash=digest(model)
 state={k:v.detach().cpu().clone() for k,v in model.state_dict().items()}
 initial_path=group/'initial.pt'
 if not initial_path.exists():torch.save(state,initial_path)
 else:
  old=torch.load(initial_path,weights_only=True);assert all(torch.equal(old[k],v) for k,v in state.items())
 graph_views=views(g,task['config'])
 truth=np.array(meta['labels']);split=ref['splits'][str(run)];tr=np.array(split['train_indices']);te=np.array(split['test_indices'])
 assert len(set(tr))==len(tr) and not set(tr)&set(te) and set(tr)|set(te)==set(range(len(truth)))
 y=torch.tensor(truth,device='cuda');train=torch.tensor(tr,device='cuda');rows=[]
 for condition in conditions:
  cv=graph_views[condition];data=neighbor_input(cv).cuda() if kind=='NeighborMLP' else cv.clone().cuda()
  out=group/condition
  if (out/'receipt.json').exists():
   rows.append(validate(out,meta,truth,te,data,kind,model,initial_hash));del data;continue
  assert not out.exists(),f'Incomplete fit requires inspection: {out}'
  out.mkdir(parents=True);model.load_state_dict(state);assert digest(model)==initial_hash
  seed(42+run);optimizer=torch.optim.Adam(model.parameters(),lr=.001,weight_decay=0)
  losses=[];started=time.perf_counter();warmup=None
  for epoch in range(200):
   model.train();optimizer.zero_grad();out_scores=logits(model,data,kind)
   loss=torch.nn.functional.cross_entropy(out_scores[train],y[train]);assert torch.isfinite(loss)
   loss.backward();optimizer.step()
   if epoch in [0,49,99,149,199]:losses.append(dict(epoch=epoch+1,training_loss=float(loss.detach())))
   if epoch==99:
    model.eval()
    with torch.no_grad():warmup=logits(model,data,kind).cpu().numpy()
  model.eval()
  with torch.no_grad():final=logits(model,data,kind).cpu().numpy()
  seconds=time.perf_counter()-started;prediction=final[te].argmax(1)
  row=dict(system=task['system'],representation=task['representation'],config=task['config'],model=kind,condition=condition,run_id=run,
    schedule='supervised200',epochs=200,init_seed=42+run,initial_weights_hash=initial_hash,final_weights_hash=digest(model),
    parameter_count=sum(p.numel() for p in model.parameters()),wall_clock_seconds=seconds,
    feature_matrix_sha256=meta['file_features_raw_bytes_sha256'],graph_sha256=sha(ROOT/'inputs'/task['system']/task['representation']/task['config']/'graph.npz'),
    splits_sha256=meta['raw_splits_sha256'],labeled_ids_sha256=hashlib.sha256(json.dumps(sorted(np.array(meta['files'])[tr].tolist()),separators=(',',':')).encode()).hexdigest(),
    protocol_sha256=sha(ROOT/'protocol.json'),code_git_sha=None,device=torch.cuda.get_device_name(),host=socket.gethostname(),
    torch_version=str(torch.__version__),file_count=len(truth),train_count=len(tr),test_count=len(te),classes=len(meta['classes']),
    embedding_seed=json.loads((ROOT/'raw'/task['system']/task['representation']/'provenance.json').read_text()).get('embedding_seed'),
    **scores(truth[te],prediction))
  save(out/'metrics.json',row);save(out/'training.json',dict(steps=200,supervised_only=True,losses=losses))
  np.savez_compressed(out/'logits.npz',final=final,warmup100=warmup)
  torch.save({k:v.detach().cpu() for k,v in model.state_dict().items()},out/'model.pt')
  pd.DataFrame(dict(file_path=np.array(meta['files'])[te],true_module=[meta['classes'][i] for i in truth[te]],pred_module=[meta['classes'][i] for i in prediction])).to_csv(out/'predictions.csv.gz',index=False)
  save(out/'receipt.json',dict(complete=True,protocol_sha256=sha(ROOT/'protocol.json'),sha256={p.name:sha(p) for p in out.iterdir() if p.is_file()}))
  del optimizer,out_scores,loss
  rows.append(validate(out,meta,truth,te,data,kind,model,initial_hash));del data
  print(json.dumps(dict(event='fit_validated',system=task['system'],representation=task['representation'],config=task['config'],model=kind,condition=condition,run=run,seconds=seconds)),flush=True)
 del model;torch.cuda.empty_cache();return rows

def run_task(index):
 task=json.loads((ROOT/'tasks.json').read_text())[index];loaded=load(task['system'],task['representation'],task['config']);rows=[]
 try:
  for run in range(task['start'],task['stop']):rows.extend(fit_group(task,run,loaded))
  p=ROOT/'outputs/task-results';p.mkdir(parents=True,exist_ok=True)
  pd.DataFrame(rows).to_csv(p/f'{index:04}.csv',index=False)
  save(ROOT/'outputs/tasks'/f'{index:04}.json',dict(state='complete',task=task,fits=len(rows),host=socket.gethostname()))
 except Exception as exc:
  save(ROOT/'outputs/tasks'/f'{index:04}.json',dict(state='failed',task=task,completed_fits=len(rows),error=repr(exc)));raise
 return dict(index=index,fits=len(rows))
