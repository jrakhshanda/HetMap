from pathlib import Path
import collections,hashlib,json,random,sys,os,importlib.metadata
import numpy as np
import torch
from torch_geometric.data import HeteroData
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'code'))
from hetmap.models.hgt import HGTNet
from gat_model import GATNet
from shared import EDGE

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,d):
 p.parent.mkdir(parents=True,exist_ok=True);tmp=p.with_suffix(p.suffix+'.tmp');tmp.write_text(json.dumps(d,indent=2)+'\n');tmp.replace(p)
def configure(device=0):
 torch.cuda.set_device(device);torch.set_num_threads(4);torch.use_deterministic_algorithms(True)
 torch.backends.cuda.matmul.allow_tf32=False;torch.backends.cudnn.allow_tf32=False
 torch.backends.cudnn.benchmark=False;torch.backends.cudnn.deterministic=True;torch.set_float32_matmul_precision('highest')
def seed(n):random.seed(n);np.random.seed(n);torch.manual_seed(n)
def digest(m):
 h=hashlib.sha256()
 for k,v in sorted(m.state_dict().items()):h.update(k.encode());h.update(str((list(v.shape),str(v.dtype))).encode());h.update(v.detach().cpu().contiguous().numpy().tobytes())
 return h.hexdigest()
def verify():
 p=json.loads((ROOT/'protocol.json').read_text())
 for name,h in p['code_sha256'].items():assert sha(ROOT/name)==h,name
 assert sha(ROOT/'prepared-manifest.json')==p['prepared_manifest_sha256']
 assert sha(ROOT/'raw-manifest.json')==p['raw_manifest_sha256']
 assert str(torch.__version__)==p['expected_runtime']['torch']
 assert importlib.metadata.version('torch-geometric')==p['expected_runtime']['pyg']
 assert np.__version__==p['expected_runtime']['numpy']
 return p
def load(system,rep,config):
 p=ROOT/'inputs'/system/rep/config
 manifest=json.loads((ROOT/'prepared-manifest.json').read_text())
 for name in ['graph.npz','metadata.json']:assert sha(p/name)==manifest[str((p/name).relative_to(ROOT))]
 meta=json.loads((p/'metadata.json').read_text());ref=json.loads((ROOT/'raw'/system/'splits.json').read_text())
 assert sha(ROOT/'raw'/system/'splits.json')==meta['raw_splits_sha256']
 g=HeteroData()
 with np.load(p/'graph.npz') as z:
  for nt in meta['node_types']:g[nt].x=torch.from_numpy(z[f'x_{nt}'].copy())
  for i,e in enumerate(meta['edge_types']):g[tuple(e)].edge_index=torch.from_numpy(z[f'edge_{i}'].copy())
 assert ref['files']==meta['files'];assert [meta['classes'][i] for i in meta['labels']]==ref['labels']
 return meta,ref,g
def views(g,config):
 if config!='F':return {'directed':g}
 assert g.node_types==['file'] and g.edge_types==[EDGE]
 a=g[EDGE].edge_index.numpy();pairs=set(map(tuple,a.T));assert all(u!=v for u,v in pairs) and len(pairs)==a.shape[1]
 result={'directed':g}
 for name,edges in [('off',set()),('undirected',pairs|{(v,u) for u,v in pairs})]:
  d=HeteroData();d['file'].x=g['file'].x;d[EDGE].edge_index=torch.from_numpy(np.array(sorted(edges),dtype=np.int64).reshape(-1,2).T.copy());result[name]=d
 return result
def neighbor_input(g):
 x=g['file'].x.numpy();a=g[EDGE].edge_index.numpy();means=np.zeros_like(x)
 if a.shape[1]:
  src,dst=a;np.add.at(means,dst,x[src]);means/=np.maximum(np.bincount(dst,minlength=len(x)),1)[:,None]
 return torch.from_numpy(np.concatenate([x,means],1))
class NeighborMLP(torch.nn.Module):
 def __init__(self,d,k):
  super().__init__();self.layers=torch.nn.Sequential(torch.nn.Linear(2*d,256),torch.nn.ReLU(),torch.nn.Linear(256,256),torch.nn.ReLU(),torch.nn.Linear(256,k))
 def forward(self,x):return self.layers(x)
def make_model(kind,g,k):
 if kind=='HGT':m=HGTNet(g,256,k,heads=4,dropout=0,num_layers=1)
 elif kind=='GAT':m=GATNet(g['file'].x.shape[1],k)
 else:assert kind=='NeighborMLP';m=NeighborMLP(g['file'].x.shape[1],k)
 m=m.cuda();m.apply(lambda v:v.reset_parameters() if hasattr(v,'reset_parameters') else None)
 return m
def logits(m,data,kind):return m(data) if kind=='NeighborMLP' else m(data)[0]
def scores(y,p):
 true=collections.Counter(y);pred=collections.Counter(p);tp=collections.Counter(y[y==p])
 return dict(f1_micro=float(100*np.mean(y==p)),f1_macro=float(100*np.mean([2*tp[c]/(true[c]+pred[c]) for c in true])))
def group_path(task,run,base=None):
 return (base or ROOT/'outputs/runs')/f"{task['system']}-{task['representation']}-{task['config']}-{task['model']}-{run:03}"
