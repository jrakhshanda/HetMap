"""Four workers per Slurm node; task ownership is disjoint across all eight GPUs."""
import os,time,socket,multiprocessing,concurrent.futures
from common import *
from train import run_task

def initialize(queue):configure(queue.get());verify()

if __name__=='__main__':
 rank=int(os.environ['SLURM_PROCID']);configure(0);verify();assert torch.cuda.device_count()==4
 assert json.loads((ROOT/'launch-gate.json').read_text())['passed']
 tasks=json.loads((ROOT/'tasks.json').read_text());indices=[i for i in range(len(tasks)) if i%2==rank]
 ctx=multiprocessing.get_context('spawn');queue=ctx.Queue()
 for gpu in range(4):queue.put(gpu)
 start=time.perf_counter();completed_fits=0
 try:
  with concurrent.futures.ProcessPoolExecutor(max_workers=4,mp_context=ctx,initializer=initialize,initargs=(queue,)) as pool:
   futures={pool.submit(run_task,index):index for index in indices}
   for done,future in enumerate(concurrent.futures.as_completed(futures),1):
    result=future.result();completed_fits+=result['fits']
    save(ROOT/'outputs'/f'node-{rank}-status.json',dict(state='running',rank=rank,host=socket.gethostname(),completed_tasks=done,total_tasks=len(indices),completed_fits=completed_fits,seconds=time.perf_counter()-start))
  save(ROOT/'outputs'/f'node-{rank}-status.json',dict(state='complete',rank=rank,completed_tasks=len(indices),completed_fits=completed_fits,seconds=time.perf_counter()-start))
 except Exception as exc:
  save(ROOT/'outputs'/f'node-{rank}-failure.json',dict(error=repr(exc),completed_fits=completed_fits,seconds=time.perf_counter()-start));raise
