"""Independent graph invariants and cross-node training replay on the frozen stack."""
import os,socket,time,copy,importlib.metadata
from common import *
from train import fit_group

def check_inputs():
 manifest=json.loads((ROOT/'prepared-manifest.json').read_text())
 for name,h in manifest.items():assert sha(ROOT/name)==h,name
 records=[]
 for system in verify()['systems']:
  for rep in verify()['representations']:
   for config in (['F'] if rep=='UXC_ZS' else ['F','FM','FF','FFM']):
    meta,ref,g=load(system,rep,config)
    for split in ref['splits'].values():
     a,b=split['train_indices'],split['test_indices'];assert not set(a)&set(b) and set(a)|set(b)==set(range(len(meta['files'])))
     assert {meta['labels'][i] for i in a}==set(meta['labels'])
    with np.load(ROOT/'inputs'/system/rep/config/'graph.npz') as z:
     for rel in g.edge_types:
      a=g[rel].edge_index.numpy();assert a.shape[0]==2 and a.shape[1]==len(set(map(tuple,a.T)))
      assert (a>=0).all() and (a[0]<len(g[rel[0]].x)).all() and (a[1]<len(g[rel[2]].x)).all()
      if rel[1]=='dependency':assert (z['owner_'+rel[0]][a[0]]!=z['owner_'+rel[2]][a[1]]).all()
    if config=='F':
     original=np.load(ROOT/'raw'/system/rep/'x.npy');assert np.array_equal(original,g['file'].x.numpy())
     vv=views(g,config);direct=set(map(tuple,vv['directed'][EDGE].edge_index.numpy().T));undirected=set(map(tuple,vv['undirected'][EDGE].edge_index.numpy().T))
     assert undirected==direct|{(v,u) for u,v in direct};assert vv['off'][EDGE].num_edges==0
     for view,graph in vv.items():
      z=neighbor_input(graph).numpy();dim=original.shape[1];assert np.array_equal(z[:,:dim],original)
      pairs=graph[EDGE].edge_index.numpy().T
      # Float64 independent neighbor mean for a bounded, fixed sample including isolates.
      for node in sorted(set([0,len(original)//2,len(original)-1])):
       src=[int(u) for u,v in pairs if v==node]
       expected=original[src].mean(0,dtype=np.float64) if src else np.zeros(dim)
       assert np.allclose(z[node,dim:],expected,atol=1e-6,rtol=1e-5)
      if view=='off':assert np.count_nonzero(z[:,dim:])==0
    records.append(dict(system=system,representation=rep,config=config,nodes=meta['node_shapes'],edges=meta['edge_counts']))
 return records

def main():
 rank=int(os.environ.get('SLURM_PROCID',0));configure(0);protocol=verify();start=time.perf_counter()
 records=check_inputs()
 cases=[]
 for rep in ['W2V','UXC_FT']:
  for model in ['HGT','GAT','NeighborMLP']:
   task=dict(system='HDF',representation=rep,config='F',model=model,conditions=['off','directed','undirected'])
   loaded=load('HDF',rep,'F');g=loaded[2];k=len(loaded[0]['classes']);seed(42);m=make_model(model,g,k)
   off=views(g,'F')['off'];data=neighbor_input(off).cuda() if model=='NeighborMLP' else off.clone().cuda();m.eval()
   with torch.no_grad():before=logits(m,data,model).cpu().numpy()
   modified=off.clone();modified['file'].x[1:]*=1.7
   data2=neighbor_input(modified).cuda() if model=='NeighborMLP' else modified.cuda()
   with torch.no_grad():after=logits(m,data2,model).cpu().numpy()
   assert np.array_equal(before[0],after[0]),'Off prediction depends on other files'
   del m,data,data2
   cases.extend(fit_group(task,0,loaded,ROOT/'pilot'/f'node-{rank}'))
  task=dict(system='HDF',representation=rep,config='FFM',model='HGT',conditions=['directed'])
  cases.extend(fit_group(task,0,load('HDF',rep,'FFM'),ROOT/'pilot'/f'node-{rank}'))
 # FFM validation in the largest system checks real memory use and runtime before the sweep.
 task=dict(system='Chrome',representation='UXC_FT',config='FFM',model='HGT',conditions=['directed'])
 cases.extend(fit_group(task,0,load('Chrome','UXC_FT','FFM'),ROOT/'pilot'/f'node-{rank}'))
 save(ROOT/f'preflight-node-{rank}.json',dict(complete=True,host=socket.gethostname(),rank=rank,
  device=torch.cuda.get_device_name(),runtime={n:importlib.metadata.version(n) for n in ['torch','torch-geometric','numpy','pandas']},
  protocol_sha256=sha(ROOT/'protocol.json'),conditions_checked=len(records),records=records,cases=cases,seconds=time.perf_counter()-start))
 print(json.dumps(dict(event='preflight_complete',rank=rank,fits=len(cases))),flush=True)

if __name__=='__main__':main()
