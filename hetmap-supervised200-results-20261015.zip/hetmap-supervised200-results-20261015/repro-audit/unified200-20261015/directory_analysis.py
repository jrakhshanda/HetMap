"""Re-evaluate the existing directory rule against new FM/FFM predictions."""
from pathlib import Path, PurePosixPath
from collections import Counter, defaultdict
import csv,gzip,json,sys,hashlib
import numpy as np
import pandas as pd
ROOT=Path(sys.argv[1]); OUT=Path(sys.argv[2]);OUT.mkdir(parents=True,exist_ok=True)
rows=[]; events=[]
for system in json.loads((ROOT/'protocol.json').read_text())['systems']:
    ref=json.loads((ROOT/'raw'/system/'splits.json').read_text())
    files=ref['files'];labels=ref['labels'];dirs=[PurePosixPath(f).parent for f in files]
    for run in range(100):
        tr=ref['splits'][str(run)]['train_indices'];te=ref['splits'][str(run)]['test_indices']
        prior=Counter(labels[i] for i in tr);exact=defaultdict(Counter);tree=defaultdict(Counter)
        for i in tr:
            d=dirs[i];exact[str(d)][labels[i]]+=1
            for a in [d,*d.parents]:tree[str(a)][labels[i]]+=1
        predictions=[]
        for i in te:
            d=dirs[i];counts=exact.get(str(d))
            if not counts:
                for a in [d,*d.parents]:
                    if str(a) in tree:counts=tree[str(a)];break
            counts=counts or prior
            predictions.append(min(counts,key=lambda c:(-counts[c],-prior[c],c)))
        y=np.array([labels[i] for i in te]);baseline=np.array(predictions);ok=baseline==y;err=~ok
        models={}
        for config in ['FM','FFM']:
            p=ROOT/'outputs/runs'/f'{system}-UXC_FT-{config}-HGT-{run:03}'/'directed'
            receipt=json.loads((p/'receipt.json').read_text())
            assert hashlib.sha256((p/'predictions.csv.gz').read_bytes()).hexdigest()==receipt['sha256']['predictions.csv.gz']
            with gzip.open(p/'predictions.csv.gz','rt') as h: pred=list(csv.DictReader(h))
            assert [r['file_path'] for r in pred]==[files[i] for i in te]
            assert [r['true_module'] for r in pred]==y.tolist()
            good=np.array([r['pred_module'] for r in pred])==y;models[config]=good
            rows.append(dict(system=system,run_id=run,config=config,test_files=len(te),
                baseline_accuracy=100*ok.mean(),model_accuracy=100*good.mean(),
                baseline_errors=int(err.sum()),baseline_correct=int(ok.sum()),
                repaired=int((err&good).sum()),damaged=int((ok&~good).sum()),
                repair_pct=100*(err&good).sum()/err.sum() if err.any() else np.nan,
                damage_pct=100*(ok&~good).sum()/ok.sum() if ok.any() else np.nan))
        events.append(dict(system=system,run_id=run,baseline_errors=int(err.sum()),
            lost=int((err&models['FM']&~models['FFM']).sum()),
            gained=int((err&~models['FM']&models['FFM']).sum())))
    print(system,flush=True)
D=pd.DataFrame(rows);E=pd.DataFrame(events)
D.to_csv(OUT/'directory_per_run.csv',index=False);E.to_csv(OUT/'directory_transitions.csv',index=False)
summaries=[]
for count in [10,100]:
    for (system,config),g in D[D.run_id<count].groupby(['system','config']):
        e=E[(E.system==system)&(E.run_id<count)]
        summaries.append(dict(system=system,config=config,splits=count,
            baseline_accuracy_median=g.baseline_accuracy.median(),model_accuracy_median=g.model_accuracy.median(),
            baseline_errors_median=g.baseline_errors.median(),repair_pct_median=g.repair_pct.median(),damage_pct_median=g.damage_pct.median(),
            pooled_repair_pct=100*g.repaired.sum()/g.baseline_errors.sum() if g.baseline_errors.sum() else np.nan,
            pooled_damage_pct=100*g.damaged.sum()/g.baseline_correct.sum(),
            lost_fm_to_ffm=int(e.lost.sum()),gained_fm_to_ffm=int(e.gained.sum())))
pd.DataFrame(summaries).to_csv(OUT/'directory_summary.csv',index=False)
(OUT/'directory_validation.json').write_text(json.dumps(dict(complete=True,model_prediction_files=2000,systems=10,splits=100,source='fresh predictions; labels used only from initial training set; saved prediction hashes verified'),indent=2))
