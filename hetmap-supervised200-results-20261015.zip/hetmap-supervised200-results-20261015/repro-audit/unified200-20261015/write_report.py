from pathlib import Path
import pandas as pd
P=Path(__file__).resolve().parent
S=pd.read_csv(P/'paired_statistics.csv')
T=pd.read_csv(P/'comparison_summary.csv')
def table(d):
    d=d.copy()
    for c in d:
        if pd.api.types.is_float_dtype(d[c]):d[c]=d[c].map(lambda x:f'{x:.2f}' if pd.notna(x) else '—')
    return '\n'.join(['| '+' | '.join(d.columns)+' |','| '+' | '.join(['---']*len(d.columns))+' |']+['| '+' | '.join(map(str,r))+' |' for r in d.itertuples(index=False,name=None)])
parts=['''# Unified 200-epoch results: interpretation and manuscript implications

Analysis of the completed 45,000-fit run, against the local paper at commit `08752e75bfe2363a1d99152ffa57db07d32db87a`. No manuscript or training output was changed. The run uses ten systems, 100 saved splits, four representations in RQ1/RQ3, three representations in RQ2, 200 supervised epochs, one frozen embedding realization, row-normalized file/member features, and merged dependency relations. All models ran on A100s under the same stack.

## Main assessment

The study remains informative, but its main explanation changes. RQ1 still supports strong dependency-informed file representations. RQ2 retains strong folder gains, while member configurations often lose performance. RQ3 now directly shows that the effect of neighbors depends on representation, predictor, and whether dependencies are used in their original direction or made bidirectional. The former universal contrast between harmful HGT propagation and helpful GAT propagation is not supported by this rerun.

These results replace the old experiment set as a coherent protocol. Changes relative to old scores cannot be attributed to any one change: schedule, normalization, relation merging, self-edge removal, selected embedding realizations and, for some earlier controls, split/population choices differ. In particular, this is not an isolated test showing that removing dependency types fixed HGT or that the old representation ranking was caused by self-training.

## RQ1: representation comparison

Median macro-F1 over 100 splits:
''',table(pd.read_csv(P/'rq1_f1_macro.csv')),
'''\nMedian micro-F1 over 100 splits:
''',table(pd.read_csv(P/'rq1_f1_micro.csv')),
'''
N2V wins six of ten systems on each metric. Macro-F1 winners otherwise are UXC-FT on TeamMates and HDC, UXC-ZS on SH-3D, and W2V on JabRef. UXC-FT wins the other four systems on micro-F1. These are descriptive median rankings, not necessarily significant wins.

UXC-FT significantly exceeds UXC-ZS on macro-F1 for nine systems and micro-F1 for all ten. SH-3D is the macro exception: FT 46.56 versus ZS 47.85; paired median change −0.43, Holm p=0.566. FT's micro gain there remains significant. N2V significantly beats W2V on nine systems, with JabRef significantly favoring W2V, for both metrics. On JabRef, FT and W2V do not differ significantly for either metric, despite different descriptive winners. On HDC, FT has the highest median micro-F1, but its paired difference from N2V is not significant.

Keep the finding that dependency-informed representations usually provide the strongest feature-only baseline, and that fine-tuning generally helps. Update the winner counts and exceptions. Do not claim universal improvement from fine-tuning or an inherent ranking independent of the classifier: input dimensions and model capacities remain different, and this rerun contains no PCA arm.

## RQ2: file, member and folder configurations

The following are medians across systems of differences between configuration medians (the existing RQ2 convention), not medians of paired run differences. Significance comes from the paired runs.
''']
q=T[(T.scope=='RQ2')&(T.metric=='f1_macro')][['contrast','representation','median_system_difference','positive_systems','significant_positive','significant_negative']]
parts += [table(q),'''
File-level HGT versus the RQ1 MLP improves median macro-F1 on nine systems with W2V and FT, and six with N2V. The median system differences are +7.50, +6.73, and +0.76 points, respectively. This comparison changes architecture as well as graph access; use RQ3 for the contribution of neighbors alone.

Folder gains survive strongly. FF−F and FFM−FM improve on all ten systems, all three representations and both metrics: 120 significant comparisons, all with large Cliff's effects. Across representations, median system macro gains are +25.57 to +44.41 for FF−F and +28.94 to +42.98 for FFM−FM. The smallest number of positive paired runs is 96/100, so the old “at least 98/100” statement must change.

Member gains do not survive as a general tendency. FM−F has median system macro changes of −12.24 W2V, −1.17 N2V, and −1.24 FT. W2V FFM−FF changes from an old positive result to −4.40 points; N2V and FT remain positive in the median (+1.58 and +1.29), but gains and significant losses occur across systems.

### A structural limit on interpreting member nodes

The saved graph audit and executed model explain why FM is not a strict addition of usable context to F. F projects member endpoints onto files. FM retains their types. The model has only one simultaneous message-passing layer, so an incoming dependency update to a member cannot then travel through its `belongs_to` edge to a file during that same layer. Files receive the member's initial projected features, not its newly updated state. This is verified from `common.py`, `code/hetmap/models/hgt.py`, and `preparation.json` in the run directory.

SH-3D and ArgoUML FM have no dependency relation ending at a file at all: their dependency edges are file→member or member→member. In this one-layer model those dependency messages cannot affect file logits through a subsequent member→file hop. TeamMates has only 16 file→file edges; other systems differ. These configurations can still use own-member features and shared learned parameters, but the presence of dependency edges in the graph does not mean their updated messages reach the prediction target.

This is a limit of the evaluated design, not proof that it alone explains every loss. W2V also changes from aggregated file content in F/FF to separate filename/member feature caches in FM/FFM; FT introduces an additional member view; N2V copies the file embedding to its member. The manuscript must describe these as configuration comparisons, not an isolated estimate of the value of member information. No model or graph was changed during this audit.

## Directory baseline: recalculated on all 100 splits

The exact existing rule was reapplied using only initial labels, with prediction hashes and file populations verified for 2,000 FM/FFM result files. Below are UXC-FT FFM comparisons. Lost/gained counts concern correct FM predictions lost, and incorrect FM predictions corrected, among files the directory baseline gets wrong; these are repeated file/split events, not unique files.
''']
d=pd.read_csv(P/'directory_summary.csv')
parts += [table(d[(d.splits==100)&(d.config=='FFM')][['system','baseline_accuracy_median','model_accuracy_median','lost_fm_to_ffm','gained_fm_to_ffm']]),'''
The directory caveat remains central. FFM exceeds the directory rule's median accuracy only on Lucene, ties SH-3D, and is lower on the other eight systems. HDF still repairs additional baseline errors, but no longer exceeds the baseline in overall accuracy. JabRef loses 544 correct FM predictions and gains 63 on the baseline-error subset, despite its aggregate improvement. Chrome loses 4,011 and gains 3,525; Bash loses 208 and gains 171; HDC loses 307 and gains 155. Lucene has 2,551 gains and 13 losses; HDF has 254 gains and 67 losses.

First-ten summaries are also exported for comparison with the old analysis. Do not mix ten-split and hundred-split event totals. A repair percentage is undefined if the baseline makes no errors; zero median errors does not mean zero errors in every split. Comparisons on baseline-error files are not automatically tests of architectural exceptions to a directory's dominant module.

## RQ3: controlled neighbor access and direction

Here the effect is the median within-system paired on/off difference, then its median across the ten systems. That convention can give different signs from subtracting two separately computed medians; both are exported and must not be mixed.
''']
q=T[(T.scope=='RQ3')&(T.metric=='f1_macro')&T.contrast.isin(['directed-off','undirected-off'])][['representation','model','contrast','median_system_paired_delta','paired_positive_systems','significant_positive','significant_negative']]
parts += [table(q),'''
For N2V, directed neighbors lower macro-F1 on six systems for HGT and GAT, and on six for neighbor MLP by paired-median sign. Undirected neighbors produce positive paired medians on eight, nine, and ten systems, respectively. HGT's remaining significant undirected losses are ArgoUML and Lucene, and several gains are tiny. For undirected GAT and neighbor MLP, eight systems improve significantly and none decline significantly. GAT's negative Bash median is not significant.

Making dependencies bidirectional is not uniformly beneficial. For N2V, all three models have negative undirected−directed paired medians on JabRef, SH-3D and TeamMates; the two latter systems also prefer directed context with the other input representations across all three predictors. Other systems often gain substantially. Thus direction handling is a system- and model-dependent factor, not a universally removable nuisance.

GAT with N2V changes from a median system paired effect of −2.84 directed to +1.42 undirected. The neighbor MLP changes from −0.65 to +1.19, and HGT from −0.64 to +0.49. This directly overturns the claim that N2V propagation losses are specific to HGT. It also strengthens the evidence that graph construction matters while holding model, vectors, initial weights, labels and training fixed.

With undirected neighbors, FT and ZS show positive macro paired medians on all ten systems for all three models. W2V has positive paired medians on seven systems for HGT, eight for GAT, and all ten for the neighbor MLP. Gains tend to be larger for ZS and W2V than for N2V, but this descriptive pattern is not a proof of input redundancy as the cause. Making edges bidirectional also changes degree and neighbor coverage; the experiment identifies the effect of this graph transformation, not the exclusive semantic value of direction.

### Which model performs best?

On the common undirected graph, GAT has the highest median macro-F1 in 33 of 40 system×representation cells: W2V 10/10, ZS 10/10, FT 7/10, N2V 6/10. Its micro-F1 win count is also 33/40: W2V 9/10, ZS 10/10, FT 10/10, N2V 4/10. These cells share systems; they are not 40 independent benchmark datasets or significance claims.

On the directed graph, HGT is strongest for N2V on six systems by macro-F1 and nine by micro-F1, while GAT wins none of the N2V three-model median comparisons. HGT exceeds GAT's N2V micro median on all ten systems (nine significant paired differences). GAT is nevertheless the leading directed predictor on most W2V and contextual cells. We can recommend GAT on the undirected merged file graph as the strongest overall tested configuration, but not declare GAT the universally best encoder or select a graph separately for each test system.

Absolute performance and benefit from neighbors remain distinct. Even with neighbors off, GAT exceeds the feature-only neighbor-MLP architecture by a median of +6.58 W2V macro points and +5.20 FT macro points across systems. Thus a stronger graph-model architecture need not owe its advantage to message passing. HGT/GAT/MLP have different parameter counts; equal epochs and hidden width are not equal model capacity. This is a comparison of the specified implementations.

## Proposed revised paper flow

1. **RQ1 — What do lexical, structural and contextual file representations provide before graph propagation?** Keep the feature-only comparison with updated counts and fine-tuning exceptions. Frame it as representations under a common classifier, not a classifier-independent ranking of information sources.
2. **RQ2 — How does mapping performance change across file, member and folder configurations?** Lead with the strong folder result and the directory-baseline qualification. Report the mixed/often negative member effects and explain one-layer reach and representation placement. Do not call F→FM simply “adding information.”
3. **RQ3 — How do the predictor and dependency direction affect the benefit of neighbor information?** Present paired on/off effects and directed/undirected effects first, then absolute encoder comparisons on each fixed graph. The ending can state that undirected GAT is the strongest overall tested file-level predictor, while N2V on the directed graph favors HGT.

Suggested central finding: **Strong file representations and useful dependency links do not guarantee that a particular propagation scheme will help. Folder context gives the most consistent gains on these reference mappings, while the contribution of dependency neighbors depends jointly on the representation, predictor and direction in which context is made available.**

The new main experiment contains no self-training, so it cannot answer a self-training RQ. Remove the training-schedule dimension from its RQ, methods, tables and conclusions. Older self-training and rewiring controls can be separately labeled supplementary evidence if retained, but they must not be presented as matched results from this 200-epoch experiment. A three-seed N2V sensitivity claim also does not apply here: this run freezes one selected original cache per system.

## Concrete manuscript changes

- `3a_results.tex`: regenerate RQ1 and RQ2 statistics/plots; replace RQ3 ten-split, three-seed, four-predictor/two-schedule account with the actual 100-split, three-model, three-condition design; replace directory repair/damage counts with the new 100-split analysis.
- `2a_methodology.tex`: replace separate dependency categories by a merged dependency relation within ordered endpoint types; retain structural relations. State cross-owner-file filtering and directed-pair deduplication. Explain normalization, one-layer member reach, GAT's no-self-loop convention, and the MLP's `[x,0]`/`[x,mean(neighbors)]` input.
- `2b_experiemnts.tex`: one supervised200 schedule, no pseudo-labeling/early stop; identical split and initialization pairing; exact RQ1/off and RQ2/F reuse; one frozen embedding realization; same A100 stack. Remove the mutually inconsistent old schedule paragraphs and old 9,600-fit count. Distinguish 45,000 distinct fits from overlapping RQ exports.
- `1a_introduction.tex`, `3b_discussion.tex`, `6_conclusion.tex`, abstract: remove HGT-specific universal loss and self-training conclusions from the new main story; replace old numbers and nine-system references. The discussion currently also calls FT dependency-free in one sentence, which is incorrect.
- `5_threats.tex`: seeds and hashes are now retained, so the old missing-seed limitation no longer applies to these runs. Retain limits from overlapping splits, ten systems, one frozen embedding realization, dimensionality/capacity differences, one-layer reach, transductive use of unlabeled features/edges, and the provenance of GT/folder agreement.
- Graph statistics: relation merging/deduplication and owner-file filtering mean any reported edge counts/degrees must match the new graph convention. Do not silently reuse degree counts for a different directed/undirected graph.

No further training is needed to describe these results accurately. Claims about the intrinsic value of member nodes, why typed HGT previously lost, or which training schedule caused earlier changes require additional controlled experiments; they should not be inferred from this replacement sweep.

## Statistical and reproducibility notes

`paired_statistics.csv` has the per-system tests, paired effects, differences of medians, split sign counts, Cliff's delta and effect bands. Two-sided Wilcoxon tests use 100 paired split differences, rounded to 12 decimal places to avoid spurious floating-point distinctions, with the normal approximation at n=100. Holm is applied separately per metric: ten systems per RQ1 contrast; 30 system×representation tests per RQ2 graph-step contrast; ten systems per fixed RQ3 representation/model/contrast or encoder contrast. These are transparent comparison families for this audit, not a claim of a newly preregistered primary test. Cliff's delta is the conventional unpaired marginal-distribution effect for compatibility with the manuscript; paired changes are also explicitly reported.

The four planned RQ1 contrasts are retained; ZS−W2V is additionally reported to check the manuscript's existing claim about the two dependency-free representations. Overlapping train/test splits and shared systems limit generalization; significance across repeated splits does not establish a population-wide encoder ranking.

Artifacts:
- `analyze_results.py`: reproducible paired analyses and descriptive rankings.
- `paired_statistics.csv`, `comparison_summary.csv`, `encoder_wins.csv`: quantitative evidence.
- `directory_analysis.py`, `directory_per_run.csv`, `directory_summary.csv`, `directory_transitions.csv`: new directory-rule evaluation for 10 and 100 splits; validation receipt included.
- `plot_results.py`, `rq3_f1_macro_effects.pdf`, `rq3_f1_micro_effects.pdf`: per-system effects, with PNG previews.
- Original verified results: `../../scenario1-run/unified-supervised200-20261015/outputs/analysis/`.
''']
(P/'REPORT.md').write_text('\n\n'.join(parts))
