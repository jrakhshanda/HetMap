from pathlib import Path
import numpy as np
import pandas as pd
from scipy.stats import wilcoxon

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
SRC = ROOT / 'scenario1-run/unified-supervised200-20261015/outputs/analysis'
D = pd.read_csv(SRC / 'long-format.csv')
METRICS = ['f1_macro', 'f1_micro']
REPS = ['W2V', 'N2V', 'UXC_ZS', 'UXC_FT']
SYSTEMS = ['A.UML','C.Img','Jabref','Lucene','SH-3D','TeamMates','Bash','HDF','Chrome','HDC']
rows = []

def compare(a,b,scope,family,**labels):
    for system in SYSTEMS:
        aa=a[a.system==system].set_index('run_id').sort_index()
        bb=b[b.system==system].set_index('run_id').sort_index()
        assert list(aa.index)==list(bb.index)==list(range(100))
        assert (aa.labeled_ids_sha256 == bb.labeled_ids_sha256).all()
        for metric in METRICS:
            x,y=aa[metric].to_numpy(),bb[metric].to_numpy()
            diff=np.round(x-y,12)
            p=wilcoxon(diff,alternative='two-sided',method='approx').pvalue if np.any(diff) else 1.
            delta=float(np.sign(x[:,None]-y[None,:]).mean())
            rows.append(dict(scope=scope,family=family,system=system,metric=metric,
                median_a=np.median(x),median_b=np.median(y),difference_of_medians=np.median(x)-np.median(y),
                median_paired_delta=np.median(diff),mean_paired_delta=np.mean(diff),
                positive_splits=int((diff>0).sum()),negative_splits=int((diff<0).sum()),p=p,
                cliffs_delta=delta,cliffs_band='N' if abs(delta)<.147 else 'S' if abs(delta)<.33 else 'M' if abs(delta)<.474 else 'L',**labels))

rq1=D[(D.model=='NeighborMLP') & (D.condition=='off')]
for a,b in [('UXC_FT','UXC_ZS'),('UXC_FT','W2V'),('UXC_FT','N2V'),('N2V','W2V'),('UXC_ZS','W2V')]:
    compare(rq1[rq1.representation==a],rq1[rq1.representation==b],'RQ1',a+'-'+b,contrast=a+'-'+b)

rq2=D[(D.model=='HGT') & (D.condition=='directed')]
for rep in ['W2V','N2V','UXC_FT']:
    r=rq2[rq2.representation==rep]
    for a,b in [('F','MLP'),('FM','F'),('FF','F'),('FFM','FM'),('FFM','FF')]:
        base=rq1[rq1.representation==rep] if b=='MLP' else r[r.config==b]
        # A family covers all 10 systems and 3 representations for one graph step.
        compare(r[r.config==a],base,'RQ2',a+'-'+b,contrast=a+'-'+b,representation=rep)

rq3=D[D.config=='F']
for rep in REPS:
    for model in ['HGT','GAT','NeighborMLP']:
        r=rq3[(rq3.representation==rep)&(rq3.model==model)]
        for a,b in [('directed','off'),('undirected','off'),('undirected','directed')]:
            # A family covers 10 systems for a fixed model, representation, contrast.
            compare(r[r.condition==a],r[r.condition==b],'RQ3',f'{rep}/{model}/{a}-{b}',
                contrast=a+'-'+b,representation=rep,model=model)
    for condition in ['off','directed','undirected']:
        r=rq3[(rq3.representation==rep)&(rq3.condition==condition)]
        for a,b in [('GAT','HGT'),('NeighborMLP','HGT'),('GAT','NeighborMLP')]:
            compare(r[r.model==a],r[r.model==b],'encoders',f'{rep}/{condition}/{a}-{b}',
                contrast=a+'-'+b,representation=rep,condition=condition)

S=pd.DataFrame(rows)
S['p_holm']=np.nan
for _,g in S.groupby(['scope','family','metric']):
    order=g.p.sort_values().index
    S.loc[order,'p_holm']=np.minimum(1,np.maximum.accumulate(S.loc[order,'p'].to_numpy()*np.arange(len(g),0,-1)))
S['significant']=S.p_holm<.05
S.to_csv(OUT/'paired_statistics.csv',index=False)
groups=['scope','contrast','representation','model','condition','metric']
summary=[]
for key,g in S.groupby(groups,dropna=False):
    summary.append(dict(zip(groups,key),**{
        'median_system_difference':g.difference_of_medians.median(),
        'median_system_paired_delta':g.median_paired_delta.median(),
        'positive_systems':int((g.difference_of_medians>1e-10).sum()),
        'paired_positive_systems':int((g.median_paired_delta>1e-10).sum()),
        'significant_positive':int((g.significant & (g.median_paired_delta>0)).sum()),
        'significant_negative':int((g.significant & (g.median_paired_delta<0)).sum()),
        'large_positive':int((g.significant & (g.cliffs_delta>=.474)).sum())}))
T=pd.DataFrame(summary)
T.to_csv(OUT/'comparison_summary.csv',index=False)
med=rq3.groupby(['system','representation','model','condition'])[METRICS].median().reset_index()
winnerrows=[]
for metric in METRICS:
    tab=rq1.groupby(['system','representation'])[metric].median().unstack().reindex(SYSTEMS)[REPS]
    tab['winner']=tab.idxmax(axis=1)
    tab.to_csv(OUT/f'rq1_{metric}.csv')
    for condition in ['off','directed','undirected']:
        t=med[med.condition==condition].pivot(index=['system','representation'],columns='model',values=metric)
        t['winner']=t.idxmax(axis=1)
        t.to_csv(OUT/f'encoder_{condition}_{metric}.csv')
        for rep,g in t.groupby(level='representation'):
            for model,count in g.winner.value_counts().items():
                winnerrows.append(dict(metric=metric,condition=condition,representation=rep,model=model,wins=count))
pd.DataFrame(winnerrows).to_csv(OUT/'encoder_wins.csv',index=False)
print('RQ1 macro:'); print(pd.read_csv(OUT/'rq1_f1_macro.csv').round(2).to_string(index=False))
print('RQ1 micro:'); print(pd.read_csv(OUT/'rq1_f1_micro.csv').round(2).to_string(index=False))
for scope in ['RQ1','RQ2','RQ3','encoders']:
    print('\n'+scope); print(T[T.scope==scope].round(3).to_string(index=False))
print('\nEncoder wins'); print(pd.DataFrame(winnerrows).to_string(index=False))
