# Unified 200-epoch results: interpretation and manuscript implications

Analysis of the completed 45,000-fit run, against the local paper at commit `08752e75bfe2363a1d99152ffa57db07d32db87a`. No manuscript or training output was changed. The run uses ten systems, 100 saved splits, four representations in RQ1/RQ3, three representations in RQ2, 200 supervised epochs, one frozen embedding realization, row-normalized file/member features, and merged dependency relations. All models ran on A100s under the same stack.

## Main assessment

The study remains informative, but its main explanation changes. RQ1 still supports strong dependency-informed file representations. RQ2 retains strong folder gains, while member configurations often lose performance. RQ3 now directly shows that the effect of neighbors depends on representation, predictor, and whether dependencies are used in their original direction or made bidirectional. The former universal contrast between harmful HGT propagation and helpful GAT propagation is not supported by this rerun.

These results replace the old experiment set as a coherent protocol. Changes relative to old scores cannot be attributed to any one change: schedule, normalization, relation merging, self-edge removal, selected embedding realizations and, for some earlier controls, split/population choices differ. In particular, this is not an isolated test showing that removing dependency types fixed HGT or that the old representation ranking was caused by self-training.

## RQ1: representation comparison

Median macro-F1 over 100 splits:


| system | W2V | N2V | UXC_ZS | UXC_FT | winner |
| --- | --- | --- | --- | --- | --- |
| A.UML | 33.51 | 54.46 | 35.92 | 46.16 | N2V |
| C.Img | 23.15 | 70.78 | 32.65 | 42.32 | N2V |
| Jabref | 43.70 | 40.12 | 39.39 | 43.03 | W2V |
| Lucene | 57.02 | 66.30 | 53.98 | 62.52 | N2V |
| SH-3D | 22.00 | 42.53 | 47.85 | 46.56 | UXC_ZS |
| TeamMates | 30.13 | 41.14 | 37.27 | 51.02 | UXC_FT |
| Bash | 6.62 | 42.47 | 22.84 | 27.04 | N2V |
| HDF | 8.40 | 52.78 | 41.57 | 46.06 | N2V |
| Chrome | 14.37 | 41.14 | 13.59 | 31.26 | N2V |
| HDC | 32.80 | 42.75 | 29.51 | 46.36 | UXC_FT |


Median micro-F1 over 100 splits:


| system | W2V | N2V | UXC_ZS | UXC_FT | winner |
| --- | --- | --- | --- | --- | --- |
| A.UML | 56.76 | 71.66 | 60.48 | 69.46 | N2V |
| C.Img | 38.97 | 80.17 | 51.83 | 62.09 | N2V |
| Jabref | 78.01 | 74.32 | 75.74 | 78.70 | UXC_FT |
| Lucene | 71.06 | 79.21 | 65.62 | 75.56 | N2V |
| SH-3D | 41.11 | 57.78 | 64.34 | 66.91 | UXC_FT |
| TeamMates | 55.19 | 68.35 | 67.55 | 78.56 | UXC_FT |
| Bash | 28.57 | 61.48 | 41.57 | 49.03 | N2V |
| HDF | 22.22 | 57.20 | 44.26 | 47.97 | N2V |
| Chrome | 48.43 | 70.51 | 48.43 | 66.19 | N2V |
| HDC | 53.45 | 68.97 | 50.57 | 69.54 | UXC_FT |


N2V wins six of ten systems on each metric. Macro-F1 winners otherwise are UXC-FT on TeamMates and HDC, UXC-ZS on SH-3D, and W2V on JabRef. UXC-FT wins the other four systems on micro-F1. These are descriptive median rankings, not necessarily significant wins.

UXC-FT significantly exceeds UXC-ZS on macro-F1 for nine systems and micro-F1 for all ten. SH-3D is the macro exception: FT 46.56 versus ZS 47.85; paired median change −0.43, Holm p=0.566. FT's micro gain there remains significant. N2V significantly beats W2V on nine systems, with JabRef significantly favoring W2V, for both metrics. On JabRef, FT and W2V do not differ significantly for either metric, despite different descriptive winners. On HDC, FT has the highest median micro-F1, but its paired difference from N2V is not significant.

Keep the finding that dependency-informed representations usually provide the strongest feature-only baseline, and that fine-tuning generally helps. Update the winner counts and exceptions. Do not claim universal improvement from fine-tuning or an inherent ranking independent of the classifier: input dimensions and model capacities remain different, and this rerun contains no PCA arm.

## RQ2: file, member and folder configurations

The following are medians across systems of differences between configuration medians (the existing RQ2 convention), not medians of paired run differences. Significance comes from the paired runs.


| contrast | representation | median_system_difference | positive_systems | significant_positive | significant_negative |
| --- | --- | --- | --- | --- | --- |
| F-MLP | N2V | 0.76 | 6 | 5 | 3 |
| F-MLP | UXC_FT | 6.73 | 9 | 8 | 1 |
| F-MLP | W2V | 7.50 | 9 | 9 | 0 |
| FF-F | N2V | 25.57 | 10 | 10 | 0 |
| FF-F | UXC_FT | 29.94 | 10 | 10 | 0 |
| FF-F | W2V | 44.41 | 10 | 10 | 0 |
| FFM-FF | N2V | 1.58 | 6 | 5 | 3 |
| FFM-FF | UXC_FT | 1.29 | 6 | 5 | 3 |
| FFM-FF | W2V | -4.40 | 3 | 2 | 5 |
| FFM-FM | N2V | 28.94 | 10 | 10 | 0 |
| FFM-FM | UXC_FT | 32.28 | 10 | 10 | 0 |
| FFM-FM | W2V | 42.98 | 10 | 10 | 0 |
| FM-F | N2V | -1.17 | 2 | 0 | 5 |
| FM-F | UXC_FT | -1.24 | 2 | 1 | 6 |
| FM-F | W2V | -12.24 | 3 | 3 | 7 |


File-level HGT versus the RQ1 MLP improves median macro-F1 on nine systems with W2V and FT, and six with N2V. The median system differences are +7.50, +6.73, and +0.76 points, respectively. This comparison changes architecture as well as graph access; use RQ3 for the contribution of neighbors alone.

Folder gains survive strongly. FF−F and FFM−FM improve on all ten systems, all three representations and both metrics: 120 significant comparisons, all with large Cliff's effects. Across representations, median system macro gains are +25.57 to +44.41 for FF−F and +28.94 to +42.98 for FFM−FM. The smallest number of positive paired runs is 96/100, so the old “at least 98/100” statement must change.

Member gains do not survive as a general tendency. FM−F has median system macro changes of −12.24 W2V, −1.17 N2V, and −1.24 FT. W2V FFM−FF changes from an old positive result to −4.40 points; N2V and FT remain positive in the median (+1.58 and +1.29), but gains and significant losses occur across systems.

### A structural limit on interpreting member nodes

The saved graph audit and executed model explain why FM is not a strict addition of usable context to F. F projects member endpoints onto files. FM retains their types. The model has only one simultaneous message-passing layer, so an incoming dependency update to a member cannot then travel through its `belongs_to` edge to a file during that same layer. Files receive the member's initial projected features, not its newly updated state. This is verified from `common.py`, `code/hetmap/models/hgt.py`, and `preparation.json` in the run directory.

SH-3D and ArgoUML FM have no dependency relation ending at a file at all: their dependency edges are file→member or member→member. In this one-layer model those dependency messages cannot affect file logits through a subsequent member→file hop. TeamMates has only 16 file→file edges; other systems differ. These configurations can still use own-member features and shared learned parameters, but the presence of dependency edges in the graph does not mean their updated messages reach the prediction target.

This is a limit of the evaluated design, not proof that it alone explains every loss. W2V also changes from aggregated file content in F/FF to separate filename/member feature caches in FM/FFM; FT introduces an additional member view; N2V copies the file embedding to its member. The manuscript must describe these as configuration comparisons, not an isolated estimate of the value of member information. No model or graph was changed during this audit.

## Directory baseline: recalculated on all 100 splits

The exact existing rule was reapplied using only initial labels, with prediction hashes and file populations verified for 2,000 FM/FFM result files. Below are UXC-FT FFM comparisons. Lost/gained counts concern correct FM predictions lost, and incorrect FM predictions corrected, among files the directory baseline gets wrong; these are repeated file/split events, not unique files.


| system | baseline_accuracy_median | model_accuracy_median | lost_fm_to_ffm | gained_fm_to_ffm |
| --- | --- | --- | --- | --- |
| A.UML | 98.48 | 92.24 | 39 | 217 |
| Bash | 91.81 | 84.82 | 208 | 171 |
| C.Img | 100.00 | 97.91 | 0 | 0 |
| Chrome | 96.83 | 90.04 | 4011 | 3525 |
| HDC | 89.08 | 86.46 | 307 | 155 |
| HDF | 93.39 | 91.80 | 67 | 254 |
| Jabref | 97.19 | 95.78 | 544 | 63 |
| Lucene | 91.45 | 97.30 | 13 | 2551 |
| SH-3D | 100.00 | 100.00 | 0 | 0 |
| TeamMates | 100.00 | 98.64 | 18 | 61 |


The directory caveat remains central. FFM exceeds the directory rule's median accuracy only on Lucene, ties SH-3D, and is lower on the other eight systems. HDF still repairs additional baseline errors, but no longer exceeds the baseline in overall accuracy. JabRef loses 544 correct FM predictions and gains 63 on the baseline-error subset, despite its aggregate improvement. Chrome loses 4,011 and gains 3,525; Bash loses 208 and gains 171; HDC loses 307 and gains 155. Lucene has 2,551 gains and 13 losses; HDF has 254 gains and 67 losses.

First-ten summaries are also exported for comparison with the old analysis. Do not mix ten-split and hundred-split event totals. A repair percentage is undefined if the baseline makes no errors; zero median errors does not mean zero errors in every split. Comparisons on baseline-error files are not automatically tests of architectural exceptions to a directory's dominant module.

## RQ3: controlled neighbor access and direction

Here the effect is the median within-system paired on/off difference, then its median across the ten systems. That convention can give different signs from subtracting two separately computed medians; both are exported and must not be mixed.


| representation | model | contrast | median_system_paired_delta | paired_positive_systems | significant_positive | significant_negative |
| --- | --- | --- | --- | --- | --- | --- |
| N2V | GAT | directed-off | -2.84 | 4 | 3 | 6 |
| N2V | HGT | directed-off | -0.64 | 4 | 4 | 6 |
| N2V | NeighborMLP | directed-off | -0.65 | 4 | 4 | 5 |
| UXC_FT | GAT | directed-off | 0.67 | 6 | 4 | 2 |
| UXC_FT | HGT | directed-off | 0.72 | 7 | 6 | 3 |
| UXC_FT | NeighborMLP | directed-off | 2.85 | 7 | 6 | 2 |
| UXC_ZS | GAT | directed-off | 3.79 | 10 | 9 | 0 |
| UXC_ZS | HGT | directed-off | 1.64 | 9 | 7 | 0 |
| UXC_ZS | NeighborMLP | directed-off | 4.81 | 8 | 7 | 1 |
| W2V | GAT | directed-off | 1.46 | 8 | 6 | 2 |
| W2V | HGT | directed-off | 0.23 | 5 | 4 | 5 |
| W2V | NeighborMLP | directed-off | 3.41 | 9 | 9 | 1 |
| N2V | GAT | undirected-off | 1.42 | 9 | 8 | 0 |
| N2V | HGT | undirected-off | 0.49 | 8 | 5 | 2 |
| N2V | NeighborMLP | undirected-off | 1.19 | 10 | 8 | 0 |
| UXC_FT | GAT | undirected-off | 3.77 | 10 | 8 | 0 |
| UXC_FT | HGT | undirected-off | 0.91 | 10 | 8 | 0 |
| UXC_FT | NeighborMLP | undirected-off | 5.77 | 10 | 10 | 0 |
| UXC_ZS | GAT | undirected-off | 8.17 | 10 | 10 | 0 |
| UXC_ZS | HGT | undirected-off | 1.79 | 10 | 10 | 0 |
| UXC_ZS | NeighborMLP | undirected-off | 7.71 | 10 | 10 | 0 |
| W2V | GAT | undirected-off | 5.56 | 8 | 7 | 0 |
| W2V | HGT | undirected-off | 2.94 | 7 | 7 | 3 |
| W2V | NeighborMLP | undirected-off | 5.08 | 10 | 10 | 0 |


For N2V, directed neighbors lower macro-F1 on six systems for HGT and GAT, and on six for neighbor MLP by paired-median sign. Undirected neighbors produce positive paired medians on eight, nine, and ten systems, respectively. HGT's remaining significant undirected losses are ArgoUML and Lucene, and several gains are tiny. For undirected GAT and neighbor MLP, eight systems improve significantly and none decline significantly. GAT's negative Bash median is not significant.

Making dependencies bidirectional is not uniformly beneficial. For N2V, all three models have negative undirected−directed paired medians on JabRef, SH-3D and TeamMates; the two latter systems also prefer directed context with the other input representations across all three predictors. Other systems often gain substantially. Thus direction handling is a system- and model-dependent factor, not a universally removable nuisance.

GAT with N2V changes from a median system paired effect of −2.84 directed to +1.42 undirected. The neighbor MLP changes from −0.65 to +1.19, and HGT from −0.64 to +0.49. This directly overturns the claim that N2V propagation losses are specific to HGT. It also strengthens the evidence that graph construction matters while holding model, vectors, initial weights, labels and training fixed.

With undirected neighbors, FT and ZS show positive macro paired medians on all ten systems for all three models. W2V has positive paired medians on seven systems for HGT, eight for GAT, and all ten for the neighbor MLP. Gains tend to be larger for ZS and W2V than for N2V, but this descriptive pattern is not a proof of input redundancy as the cause. Making edges bidirectional also changes degree and neighbor coverage; the experiment identifies the effect of this graph transformation, not the exclusive semantic value of direction.

### Which model performs best?

On the common undirected graph, GAT has the highest median macro-F1 in 33 of 40 system×representation cells: W2V 10/10, ZS 10/10, FT 7/10, N2V 6/10. Its micro-F1 win count is also 33/40: W2V 9/10, ZS 10/10, FT 10/10, N2V 4/10. These cells share systems; they are not 40 independent benchmark datasets or significance claims.

On the directed graph, HGT is strongest for N2V on six systems by macro-F1 and nine by micro-F1, while GAT wins none of the N2V three-model median comparisons. HGT exceeds GAT's N2V micro median on all ten systems (nine significant paired differences). GAT is nevertheless the leading directed predictor on most W2V and contextual cells. We can recommend GAT on the undirected merged file graph as the strongest overall tested configuration, but not declare GAT the universally best encoder or select a graph separately for each test system.

Absolute performance and benefit from neighbors remain distinct. Even with neighbors off, GAT exceeds the feature-only neighbor-MLP architecture by a median of +6.58 W2V macro points and +5.20 FT macro points across systems. Thus a stronger graph-model architecture need not owe its advantage to message passing. HGT/GAT/MLP have different parameter counts; equal epochs and hidden width are not equal model capacity. This is a comparison of the specified implementations.

## Proposed revised paper flow

1. **RQ1 — What do lexical, structural and contextual file representations provide before graph propagation?** Keep the feature-only comparison with updated counts and fine-tuning exceptions. Frame it as representations under a common classifier, not a classifier-independent ranking of information sources.
2. **RQ2 — How does mapping performance change across file, member and folder configurations?** Lead with the strong folder result and the directory-baseline qualification. Report the mixed/often negative member effects and explain one-layer reach and representation placement. Do not call F→FM simply “adding information.”
3. **RQ3 — How do the predictor and dependency direction affect the benefit of neighbor information?** Present paired on/off effects and directed/undirected effects first, then absolute encoder comparisons on each fixed graph. The ending can state that undirected GAT is the strongest overall tested file-level predictor, while N2V on the directed graph favors HGT.

Suggested central finding: **Strong file representations and useful dependency links do not guarantee that a particular propagation scheme will help. Folder context gives the most consistent gains on these reference mappings, while the contribution of dependency neighbors depends jointly on the representation, predictor and direction in which context is made available.**

The new main experiment contains no self-training, so it cannot answer a self-training RQ. Remove the training-schedule dimension from its RQ, methods, tables and conclusions. Older self-training and rewiring controls can be separately labeled supplementary evidence if retained, but they must not be presented as matched results from this 200-epoch experiment. A three-seed N2V sensitivity claim also does not apply here: this run freezes one selected original cache per system.

## Concrete manuscript changes

- `3a_results.tex`: regenerate RQ1 and RQ2 statistics/plots; replace RQ3 ten-split, three-seed, four-predictor/two-schedule account with the actual 100-split, three-model, three-condition design; replace directory repair/damage counts with the new 100-split analysis.
- `2a_methodology.tex`: replace separate dependency categories by a merged dependency relation within ordered endpoint types; retain structural relations. State cross-owner-file filtering and directed-pair deduplication. Explain normalization, one-layer member reach, GAT's no-self-loop convention, and the MLP's `[x,0]`/`[x,mean(neighbors)]` input.
- `2b_experiemnts.tex`: one supervised200 schedule, no pseudo-labeling/early stop; identical split and initialization pairing; exact RQ1/off and RQ2/F reuse; one frozen embedding realization; same A100 stack. Remove the mutually inconsistent old schedule paragraphs and old 9,600-fit count. Distinguish 45,000 distinct fits from overlapping RQ exports.
- `1a_introduction.tex`, `3b_discussion.tex`, `6_conclusion.tex`, abstract: remove HGT-specific universal loss and self-training conclusions from the new main story; replace old numbers and nine-system references. The discussion currently also calls FT dependency-free in one sentence, which is incorrect.
- `5_threats.tex`: seeds and hashes are now retained, so the old missing-seed limitation no longer applies to these runs. Retain limits from overlapping splits, ten systems, one frozen embedding realization, dimensionality/capacity differences, one-layer reach, transductive use of unlabeled features/edges, and the provenance of GT/folder agreement.
- Graph statistics: relation merging/deduplication and owner-file filtering mean any reported edge counts/degrees must match the new graph convention. Do not silently reuse degree counts for a different directed/undirected graph.

No further training is needed to describe these results accurately. Claims about the intrinsic value of member nodes, why typed HGT previously lost, or which training schedule caused earlier changes require additional controlled experiments; they should not be inferred from this replacement sweep.

## Statistical and reproducibility notes

`paired_statistics.csv` has the per-system tests, paired effects, differences of medians, split sign counts, Cliff's delta and effect bands. Two-sided Wilcoxon tests use 100 paired split differences, rounded to 12 decimal places to avoid spurious floating-point distinctions, with the normal approximation at n=100. Holm is applied separately per metric: ten systems per RQ1 contrast; 30 system×representation tests per RQ2 graph-step contrast; ten systems per fixed RQ3 representation/model/contrast or encoder contrast. These are transparent comparison families for this audit, not a claim of a newly preregistered primary test. Cliff's delta is the conventional unpaired marginal-distribution effect for compatibility with the manuscript; paired changes are also explicitly reported.

The four planned RQ1 contrasts are retained; ZS−W2V is additionally reported to check the manuscript's existing claim about the two dependency-free representations. Overlapping train/test splits and shared systems limit generalization; significance across repeated splits does not establish a population-wide encoder ranking.

Artifacts:
- `analyze_results.py`: reproducible paired analyses and descriptive rankings.
- `paired_statistics.csv`, `comparison_summary.csv`, `encoder_wins.csv`: quantitative evidence.
- `directory_analysis.py`, `directory_per_run.csv`, `directory_summary.csv`, `directory_transitions.csv`: new directory-rule evaluation for 10 and 100 splits; validation receipt included.
- `plot_results.py`, `rq3_f1_macro_effects.pdf`, `rq3_f1_micro_effects.pdf`: per-system effects, with PNG previews.
- Original verified results: `../../scenario1-run/unified-supervised200-20261015/outputs/analysis/`.
