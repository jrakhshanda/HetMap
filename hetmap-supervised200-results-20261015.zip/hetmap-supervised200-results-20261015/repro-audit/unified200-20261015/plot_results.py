from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

P=Path(__file__).resolve().parent
S=pd.read_csv(P/'paired_statistics.csv')
systems=['A.UML','C.Img','Jabref','Lucene','SH-3D','TeamMates','Bash','HDF','Chrome','HDC']
reps=['W2V','UXC_ZS','UXC_FT','N2V'];models=['HGT','GAT','NeighborMLP']
for metric in ['f1_macro','f1_micro']:
    fig,axes=plt.subplots(1,3,figsize=(19,8),layout='constrained')
    for ax,contrast,title in zip(axes,['directed-off','undirected-off','undirected-directed'],['Directed − off','Undirected − off','Undirected − directed']):
        d=S[(S.scope=='RQ3')&(S.metric==metric)&(S.contrast==contrast)].set_index(['representation','model','system'])
        mat=np.array([[d.loc[(rep,model,s),'median_paired_delta'] for s in systems] for rep in reps for model in models])
        im=ax.imshow(mat,cmap='RdBu',vmin=-12,vmax=12,aspect='auto')
        ax.set_xticks(range(10),systems,rotation=60,ha='right')
        ax.set_yticks(range(12),[f'{rep} · {model.replace("NeighborMLP","MLP")}' for rep in reps for model in models])
        ax.set_title(title)
        for i,(rep,model) in enumerate((r,m) for r in reps for m in models):
            for j,s in enumerate(systems):
                star='*' if d.loc[(rep,model,s),'significant'] else ''
                ax.text(j,i,f'{mat[i,j]:+.1f}{star}',ha='center',va='center',fontsize=8,color='white' if abs(mat[i,j])>8 else 'black')
        for y in [2.5,5.5,8.5]:ax.axhline(y,color='white',lw=2)
    fig.colorbar(im,ax=axes,label='Median paired change (F1 percentage points)',shrink=.65)
    fig.suptitle(f'RQ3: {metric.replace("f1_", "").capitalize()}-F1 · 100 paired splits · 200 supervised epochs\n* Wilcoxon, Holm across ten systems within each representation/model/contrast; p < 0.05',fontsize=13)
    fig.savefig(P/f'rq3_{metric}_effects.pdf')
    fig.savefig(P/f'rq3_{metric}_effects.png',dpi=160)
    plt.close(fig)
