# HetMap: unified supervised-200 results

Start with `repro-audit/unified200-20261015/REPORT.md` for findings and implications for the paper.

## Completed experiment

- Ten systems, including ArgoUML; 100 saved labeled/test splits per condition.
- Exactly 200 supervised epochs, no self-training or pseudo-labels.
- Frozen representations; one selected original N2V cache per system.
- A common A100 hardware/software setup across the run.
- RQ1: W2V, N2V, UniXcoder zero-shot and fine-tuned, feature-only MLP.
- RQ2: W2V, N2V and UniXcoder fine-tuned, HGT F/FM/FF/FFM with directed merged dependencies.
- RQ3: all four representations, HGT/GAT/neighbor MLP, off/directed/undirected.
- 45,000 distinct trained fits. Final validation passed, including 90,000 metric checks, checkpoint replay and initialization pairing.

## Results

`scenario1-run/unified-supervised200-20261015/outputs/analysis/` contains:

- `long-format.csv`: 45,000 rows with per-fit metrics and provenance.
- `rq1-per-run.csv`: 4,000 rows.
- `rq2-per-run.csv`: 12,000 rows.
- `rq3-per-run.csv`: 36,000 rows.
- Per-RQ medians, RQ3 paired deltas/effects and `validation.json`.

RQ exports overlap intentionally: RQ1 reuses neighbor-MLP off; RQ2 F reuses directed HGT. Do not concatenate the three exports as independent fits. Metric values use a 0-100 scale. For MLP, off is `[x,0]` and on is `[x,mean(incoming neighbors)]`.

`repro-audit/unified200-20261015/` contains the written assessment, paired statistical tests, encoder comparisons, macro/micro effect figures, and the updated directory-baseline analysis over 100 splits (with separate first-ten summaries). The report distinguishes paired median deltas from differences of medians and states the Holm correction families.

## Configuration, code and data provenance

The run directory includes `protocol.json`, source provenance, raw/prepared input hash manifests, graph preparation audit, preflight/cross-node validation, launch records, frozen training/analysis code and saved split files. The original run README describes launch-time monitoring; the final validation receipt is the completion record.

This is a results/review package, not a full training-data mirror. It excludes large embedding matrices, source archives, prepared graph arrays, per-fit checkpoints/logits and per-file prediction archives. Those remain in the original experiment storage. Hash manifests identify those inputs/outputs. Analysis of the included per-fit scores is reproducible locally; retraining and rerunning the directory prediction audit require the omitted original assets.

## Reproduce the score analysis

Preserve the ZIP's directory structure and use a Python environment with numpy, pandas, scipy and matplotlib. The review used pandas 3.0.6 and scipy 1.14.1.

From this package root:

```
python repro-audit/unified200-20261015/analyze_results.py
python repro-audit/unified200-20261015/plot_results.py
python repro-audit/unified200-20261015/write_report.py
```

`Results_overview.ipynb` provides a short entry point to the tables and figures. No training is performed by it.

The paper has not been edited. Proposed follow-up tests (100-vs-200 checkpoint analysis, two-layer HGT, reverse-only dependencies) are not part of these completed results.

`MANIFEST.sha256` covers every included file other than the manifest itself.
